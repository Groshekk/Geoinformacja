---
przedmiot: Monitoring środowiska przyrodniczego
date_zajec:
rodzaj_zajec: 
prowadzacy: Józef Szpikowski, Maciej Major, Mikołaj Majewski
date: 09.12.2023
type: notatki
tags: notatki, geoinformacja, studia, IIrok
---

# Zakres tematyczny wykładów
- podstawowe założenia metodologiczne i metodyczne Monitoringu Środowiska Przyrodniczego 
- zastosowanie teorii funkcjonowania geoekosystemu do organizacji terenowego systemu monitoringu
- systemy monitoringu w Polsce i Europie
- podstawy meteorologii w monitoringu środowiska przyrodniczego
- przegląd wybranych programów pomiarowych monitoringu środowiska przyrodniczego, dokumentacja i  interpretacja wyników badań
- geowskaźniki w monitoringu środowiska przyrodniczego
- bazy danych i internetowe źródła informacji o monitoringu środowiska przyrodniczego
- badawcze i aplikacyjne znaczenie monitoringu środowiska przyrodniczego
---
# Bibliografia
- *[Zintegrowany Monitoring Środowiska Przyrodniczego. Współczesne przemiany naturalne i antropologiczne środowiska przyrodniczego zlewni rzecznych i jeziornych](https://bogucki.home.pl/repozytorium/9788379864485/978-83-7986-448-5.pdf)*; A. Kostrzewski, J. Szpikowski, M. Majewski; 2022
	- *Koncepcja organizacji i realizacji programu Zintegrowanego Monitoringu Środowiska Przyrodniczego w latach 1992-2022*; A. Kostrzewski
	- *Wybrane procedury kontroli jakości danych pomiarowych w programie ZMŚP na poziomie Centralnej Bazy Danych*; R. Kruszyk; 72-84
- *[Stan geoekosystemów Polski w 2021 roku na podstawie badań Zintegrowanego Monitoringu Środowiska Przyrodniczego](https://centrumzmsp.home.amu.edu.pl/wp-content/uploads/2022/09/Raport_2021.pdf)*; M. Majewski, A. Kostrzewski
- *[Stan środowiska w Polsce. Raport 2018](https://www.gov.pl/attachment/00f9a6d4-d48b-4e22-b52d-dacebb49e9c4)*; 2018; Warszawa: Główny Inspektorat Ochrony Środowiska
- *[Stan środowiska w Polsce. Raport 2022](https://www.gov.pl/attachment/8193fbd1-9302-4d30-a483-bde6c8f5564a)*; 2022; Warszawa: Główny Inspektorat Ochrony Środowiska
---
# Zadania z egzaminu (**08.02.2024**)
1. Opisać cele monitoringu środowiska przyrodniczego.
2. Opisać powstanie i zasady Państwowego Monitoringu Środowiska Przyrodniczego.
3. Opisać zasady cykliczności i jednolitości metod stosowanych w monitoringu środowiska przyrodniczego.
4. Opisać wskaźniki stosowane w monitoringu wody powierzchniowej.
5. Opisać sposób określania stopnia synantropizacji krajobrazu na podstawie mapy pokrycia terenu i użytkowania ziemi.
---
# Notatki
## Notatki z wykładów
1. Metodologia i metodyka PMŚ
	zrównoważony rozwój
	Państwowy Monitoring Środowiska
	Zintegrowany Monitoring Środowiska Przyrodniczego
2. Geoekosystem
3. Rodzaje monitoringów
4. Metody pomiarowe. Inne monitoringi. Procesy ekstremalne
	metody pomiarowe
	inne monitoringi
	procesy ekstremalne
---
## Notatki z laboratoriów
1. Struktura monitoringu środowiska przyrodniczego w Polsce
2. Monitoring obiegu wody i spłukiwania na stokach
3. Współczynnik kontynentalizmu W. Gorczyńskiego
4. Wskaźniki i współczynniki przyrodnicze
5. Analiza jakości powietrza
---
---
---
---
---
# Definicje z notatek
##### **monitoring środowiska przyrodniczego** (definicja)
>przedstawienie organizacji i systemu pomiarowego wybranych elementów środowiska przyrodniczego, formułowanie prawidłowości w zakresie stanu aktualnego środowiska przyrodniczego, kierunków zagrożeń i ochrony, przedstawianie prognozy jego rozwoju w oparciu o naturę funkcjonowania środowiska przyrodniczego
---

##### **Zintegrowany Monitoring Środowiska Przyrodniczego** (**ZMŚP**) (definicja)
>ogólnopolski program, który funkcjonuje w ramach Państwowego Monitoringu Środowiska, obok monitoringów specjalistycznych, w ramach tzw. bloku *Przyroda*
---

##### **zlewnia rzeczna** (w kontekście **zrównoważonego rozwoju**) (definicja)
>obiekt przyrodniczy, w którym można w sposób kompleksowy wprowadzać i oceniać rezultaty realizowanej polityki zrównoważonego rozwoju
---

##### **Państwowy Monitoring Środowiska** (**PMŚ**) (***Ustawa o Inspekcji Ochrony Środowiska***) (definicja I)
>system pomiarów, ocen i prognoz stanu środowiska
---

##### **Państwowy Monitoring Środowiska** (**PMŚ**) (***Ustawa o Inspekcji Ochrony Środowiska***) (definicja II)
>system gromadzenia, przetwarzania i rozpowszechniania informacji o środowisku
---

##### **monitoring środowiska przyrodniczego** (definicja)
>przedstawienie organizacji i systemu pomiarowego wybranych elementów środowiska przyrodniczego, formułowanie prawidłowości w zakresie stanu aktualnego środowiska przyrodniczego, kierunków zagrożeń i ochrony, przedstawianie prognozy jego rozwoju w oparciu o naturę funkcjonowania środowiska przyrodniczego
---

##### **Zintegrowany Monitoring Środowiska Przyrodniczego** (**ZMŚP**) (definicja)
>ogólnopolski program, który funkcjonuje w ramach Państwowego Monitoringu Środowiska, obok monitoringów specjalistycznych, w ramach tzw. bloku *Przyroda*
---

##### **krajobraz** (**rozumienie geograficzne**) (definicja I)
>dynamiczny układ wyrażający efekty procesów zarówno naturalnych jak i związanych z działalnością człowieka
---

##### **krajobraz** (**rozumienie geograficzne**) (definicja II)
>geosystem składający się z powiązanych funkcjonalnie subsystemów zbudowanych z różnych elementów
---

##### **krajobraz** (**rozumienie potoczne**) (definicja)
>wygląd środowiska składającego się z naturalnych, wytworzonych przez człowieka struktur znajdujących się na powierzchni Ziemi
---

##### **metoda** (definicja)
>logiczny ciąg (algorytm) operacji wykonywanych podczas pomiaru
---

##### **metoda bezpośrednia** (definicja)
>sposób pomiaru, w którym wynik pomiaru otrzymuje się na podstawie wskazania przyrządu wywzorcowanego w jednostkach miary danej wielkości
---

##### **metoda bezpośredniego porównania** (definicja)
>metoda pomiaru bezpośredniego polegająca na porównaniu całkowitej wartości wielkości mierzonej ze znaną wartością wzorcową tej wielkości wchodzącą bezpośrednio do pomiaru (wskazania *K* przyrządu stanowi wynik *X* pomiaru: *X = K*)
---

##### **metoda różnicowa** (definicja)
>metoda pomiaru bezpośredniego polegająca na odjęciu od wielkości mierzonej *X* znanej wartości wzorcowej *W* i pomiarze otrzymanej różnicy *K* metodą bezpośredniego porównania (*X = W + K*)
---

##### **metoda zerowa** (definicja)
>metoda pomiaru bezpośredniego polegająca na badaniu różnicy między wielkością mierzoną a wzorcową i takiej zmianie wielkości wzorcowej, aby tę różnicę sprowadzić do zera (wynik pomiaru *X* równy wartości wzorca *W: X = W*)
---

##### **metoda pośrednia** (definicja)
>metoda pomiaru polegający na bezpośrednim pomiarze innych wielkości związanych z wielkością szukaną znaną zależnością (wyznaczenie wartość *X* mierzonej wielkości *X = f(A; B; C; ...)*)
---

##### **zjawisko ekstremalne** (definicja **I**)
>nadzwyczajny fakt zachodzący w rzeczywistości, możliwy do zaobserwowania, zmierzenia i oceny za pomocą przyjętych metod
---

##### **zjawisko ekstremalne** (definicja **II**)
>zjawisko lub wartość bliskie ekstremom absolutnym danej charakterystyki (klimatycznej, hydrologicznej), których prawdopodobieństwo przekroczenia jest mniejsze od 10%, czyli szansa ich wystąpienia (okres powtarzalności) wynosi raz na 10 lat
---

##### **zjawisko ekstremalne wyjątkowe** (definicja)
>zjawisko lub wartość bliskie ekstremom absolutnym danej charakterystyki (klimatycznej, hydrologicznej), których prawdopodobieństwo przekroczenia jest mniejsze od 1%, czyli szansa ich wystąpienia (okres powtarzalności) wynosi raz na 100 lat
---

##### **zdarzenie ekstremalne** (definicja)
>zjawisko ekstremalne zachodzące w czasoprzestrzeni, czyli takie, dla którego można określić położenie i czas występowania
---

##### **proces ekstremalny** (definicja)
>ukierunkowany ciąg zachodzących w czasoprzestrzeni i powiązanych przyczynowo zmian; o ekstremalnym charakterze procesu świadczy jego natężenie powiązane z przetworzeniem stanu wejściowego w stan wyjściowy (okresowe, długookresowe, trwałe)
---

##### **proces katastrofalny** (definicja)
>proces ekstremalny niosący z sobą negatywne konsekwencje dla środowiska oraz zagrożenia dla gospodarki i człowieka
---

##### **wartość absolutna minimalna**/**ekstremum absolutne minimalne**/**absolutne minimum** (definicja)
>wartość najniższa, jaka do tej pory została stwierdzona w charakterystyce danego zjawiska
---

##### **wartość absolutna maksymalna**/**ekstremum absolutne maksymalne**/**absolutne maksimum** (definicja)
>wartość najwyższa, jaka do tej pory została stwierdzona w charakterystyce danego zjawiska
---

##### **klęska żywiołowa** (definicja)
>losowa katastrofa spowodowane siłami natury lub działaniem człowieka wywołujące zniszczenia, szkody i ofiary śmiertelne
---

---
---
---
---
---
