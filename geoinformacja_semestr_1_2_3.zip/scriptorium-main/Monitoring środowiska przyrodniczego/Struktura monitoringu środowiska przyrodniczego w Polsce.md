---
przedmiot: Monitoring środowiska przyrodniczego
date_zajec: 06.12.2023
rodzaj_zajec: laboratorium
prowadzacy: Maciej Major
date: 06.12.2023
type: notatki
tags: notatki, geoinformacja, studia, IIrok
---

# Struktura monitoringu środowiska przyrodniczego w Polsce
zajęcia I (06.12.2023) - zajęcia w formie wykładowej

struktura monitoringu środowiska przyrodniczego w Polsce

---
## Zajęcia
###  Definicje monitoringu środowiska przyrodniczego
##### monitoring środowiska przyrodniczego (definicja)
>przedstawienie organizacji i systemu pomiarowego wybranych elementów środowiska przyrodniczego, formułowanie prawidłowości w zakresie stanu aktualnego środowiska przyrodniczego, kierunków zagrożeń i ochrony, przedstawianie prognozy jego rozwoju w oparciu o naturę funkcjonowania środowiska przyrodniczego
---

---
---
>*Monitoring środowiska przyrodniczego w oparciu o naturę funkcjonowania środowiska przyrodniczego przedstawia organizację i system pomiarowy wybranych elementów środowiska przyrodniczego, formuje prawidłowości w zakresie stanu aktualnego środowiska przyrodniczego, kierunków zagrożeń i ochrony oraz przedstawia prognozy jego rozwoju.*
---
---

##### Zintegrowany Monitoring Środowiska Przyrodniczego (**ZMŚP**) (definicja)
>ogólnopolski program, który funkcjonuje w ramach Państwowego Monitoringu Środowiska, obok monitoringów specjalistycznych, w ramach tzw. bloku *Przyroda*
---
### Struktura monitoringu środowiska przyrodniczego w Polsce
#### struktura monitoringu środowiska przyrodniczego w Polsce
- Państwowy Monitoring Środowiska (**PMŚ**)
	- Zintegrowany Monitoring Środowiska Przyrodniczego (**ZMŚP**)
		- monitoringi specjalistyczne **ZMŚP**
	- monitoringi specjalistyczne **PMŚ**
---
#### struktura Zintegrowanego Monitoringu Środowiska Przyrodniczego (**ZMŚP**)
- Ministerstwo Klimatu i Środowiska (**MiKŚ**) - minister (Anna Łukaszewska-Trzeciakowska → Paulina Hennig-Kloska)
	- Główny Inspektorat Ochrony Środowiska (**GIOŚ**) - główny inspektor (Krzysztof Gołębiewski)
		- Departament Monitoringu i Informacji o Środowisku - dyrektor departamentu (Katarzyna Wiech)
			- Koordynator Zintegrowanego Monitoringu Środowiska Przyrodniczego - koordynator (prof. Andrzej Kostrzewski) - nadzór funkcjonowania Stacji Bazowych
				- Stacje Bazowe (12)
					- **Stacja Bazowa Wolin** (*Stacja Bazowa Biała Góra*) - UAM (prof. Jacek Tylkowski)
						- monitoring abrazji wybrzeży klifowych
					- **Stacja Bazowa Parsęta** (*Stacja Bazowa Storkowo*) - UAM (Stacja Geoekologiczna w Storkowie) (prof. Józef Szpikowski)
						- monitoring erozji wodnej gleb
					- **Stacja Bazowa Pojezierze Chełmińskie** (*Stacja Bazowa Koniczynka*) - UMK (prof. Marek Kejna)
					- **Stacja Bazowa Puszcza Borecka** - Instytut Ochrony Środowiska (**IOŚ-PIB**) w Warszawie (dr inż. Krzysztof Skotak?/dr inż. Anna Degórska?)
					- **Stacja Bazowa Wigry** - Wigierski Park Narodowy (mgr Aleksandra Mackiewicz)
					- **Stacja Bazowa Kampinos** (*Stacja Bazowa Pożary*) - Kampinoski Park Narodowy (dr inż. Adam Olszewski)
					- **Stacja Bazowa Łysogóry** (*Stacja Bazowa Święty Krzyż*) - Uniwersytet Jana Kochanowskiego (prof. Rafał Kozłowski)
					- **Stacja Bazowa Roztocze** - Roztoczański Park Narodowy (dr inż. Przemysław Stachyra)
					- **Stacja Bazowa Beskid Niski** (*Stacja Bazowa Szymbark*) - Instytut Geografii i Przestrzennego Zagospodarowania PAN (**IGiPZ PAN**) (prof. Małgorzata Kijowska-Strugała)
						- monitoring osuwisk
					- **Stacja Bazowa Karkonosze** - Karkonoski Park Narodowy (mgr Krzysztof Krakowski)
					- **Stacja Bazowa Poznań-Morasko** (*Stacja Bazowa Różany Strumień*) - UAM (prof. Maciej Major)
						- monitoring migracji zanieczyszczeń w wodach podziemnych
					- **Stacja Bazowa Pogórze Karpackie** - UJ (dr inż. Mariusz Klimek) (w Łazach)
				- stacja referencyjna (1)
					- **Stacja Petuniabukta na Spitsbergenie** - UAM (mgr Krzysztof Rymer)
---
#### chronologia uruchamiania Stacji Bazowych **ZMŚP**
- pierwotny układ:
	- Stacja Bazowa Parsęta
	- Stacja Bazowa Pojezierze Chełmińskie
	- Stacja Bazowa Puszcza Borecka
	- Stacja Bazowa Wigry
	- Stacja Bazowa Kampinos
	- Stacja Bazowa Łysogóry
	- Stacja Bazowa Beskid Niski
- rozszerzenie I:
	- Stacja Bazowa Wolin
	- Stacja Bazowa Roztocze
- rozszerzenie II (**2013**):
	- Stacja Bazowa Poznań-Morasko
	- Stacja Bazowa Karkonosze
- rozszerzenie III (**2022**):
	- Stacja Bazowa Pogórze Karpackie
---
#### programy Zintegrowanego Monitoringu Środowiska Przyrodniczego (**ZMŚP**)
- programy pomiarowe **ZMŚP** (17) - teren na powierzchniach badawczych
	- Meteorologia (**A1**)
	- Zanieczyszczenie powietrza (**B1**)
	- Chemizm opadów atmosferycznych (**C1**)
	- Chemizm opadu podkoronowego (**C2**)
	- Chemizm spływu po pniach (**C3**)
	- Metale ciężkie i siarka w porostach (**D1**)
	- Metale ciężkie i siarka w machach (**D2**)
	- Gleby (**E1**)
	- Chemizm roztworów glebowych (**F1**)
	- Wody podziemne (**F2**)
	- Opad organiczny (**G2**)
	- Wody powierzchniowe - rzeki (**H1**)
	- Wody powierzchniowe - jeziora (**H2**)
	- Hydrobiologia rzek - makrofity i ocena (**I1**)
	- Struktura i dynamika szaty roślinnej (**J2**)
	- Monitoring gatunków inwazyjnych obcego pochodzenia (**J3**)
	- Uszkodzenia drzew i drzewostanów (**K1**)
- programy analityczne **ZMŚP** (5) - prace gabinetowe
	- Zmiany pokrycia terenu i użytkowania ziemi
	- Świadczenia geoekosystemów
	- Modelowanie zmian bilansu wodnego i biogeochemicznego dla zlewni reprezentatywnych **ZMŚP**
	- ...
---

---
---
>*Na stajach bazowych na wyznaczonych powierzchniach testowych, które są reprezentatywne dla danego obszaru gromadzone są dane w oparciu o system pomiarowy **ZMŚP**, muszą opierać się na sprawdzonych i porównywalnych metodach badań terenowych i analiz laboratoryjnych. Zebrane dane zostają poddane obróbce statystyczne, zostają zakodowane i w postaci plików przesłane do Centralnej Bazy Danych ZMŚP. W odróżnieniu od monitoringów specjalistycznych w **ZMŚP** jest wskazane, aby ujmować jak największą liczbę elementów środowiska przyrodniczego, wykrywać zależności między nimi, na tej podstawie określać zagrożenia i tendencje rozwoju środowiska. Badania powinny być prowadzone w systemie ciągłym i w cyklu wieloletnim.*
---
---

---
#### strony internetowe dotyczące monitoringu środowiska przyrodniczego
- [Instytut Meteorologii i Gospodarki Wodnej - Państwowy Instytut Badawczy](https://imgw.pl/) (**IMGW-PIB**)
	- [serwis METEO](http://meteo.imgw.pl/)
	- zakładka Oddziału morskiego w Gdyni **IMGW-PIB** (mapa wód terytorialnych)
- [Państwowy Instytut Geologiczny - Państwowy Instytut Badawczy](https://www.pgi.gov.pl/) (**PIG-PIB**)
- [Ministerstwo Klimatu i Środowiska](https://www.gov.pl/web/klimat) (**MKiŚ**)
- [Główny Inspektorat Ochrony Środowiska](https://www.gov.pl/web/gios) (**GIOŚ**)
	- [stara strona **GIOŚ**](https://www.gios.gov.pl/pl/)
- [Zintegrowany Monitoring Środowiska Przyrodniczego](https://centrumzmsp.web.amu.edu.pl/) (**ZMŚP**)
- [Deutscher Wetterdienst](https://www.dwd.de/EN/Home/home_node.html) (**DWD**)
- [Światowa Organizacja Meteorologiczna](https://wmo.int/) (*The World Meteorological Organization*, **WMO**)
- [Integrated Monitoring](http://info1.ma.slu.se/IM/IMeng.html) (**IM**)
---
