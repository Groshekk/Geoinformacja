---
przedmiot: Kartografia cyfrowa
date_zajec:
rodzaj_zajec: wykład
prowadzacy: Beata Janczak-Kostecka
date: 10.10.2023
type: notatki
tags: notatki, geoinformacja, studia, IIrok
---

# Zakres tematyczny zajęć
1. Systemy informacji geograficznej
2. Działania w kartografii cyfrowej - cyfrowy model krajobrazowy i kartograficzny
3. Pozyskiwanie danych przestrzennych
4. Metody generalizacji w kartografii cyfrowej
5. Typy map zjawisk punktowych, liniowych i powierzchniowych
6. Kartodiagram
7. Jakościowe metody mapowania (rodzaje sygnatur, sygnatury stopniowe)
8. Ilościowe metody mapowania (kartogram, kartogram złożony)
9. Zasady projektowania map. Projektowanie map tematycznych
10. Zastosowanie etykiet na mapach 
11. Barwy w kartografii 
12. Metody mapowania. Etapy opracowania map
13. Mapy i bazy w systemie informacji przestrzennej
14. Kartografia multimedialna - prezentacja kartograficzna w geomediach
---
# Bibliografia
- *QGIS map design*; A. Graser; 2018
- *[Kartografia. Zasady i zastosowania geowizualizacji](https://lubimyczytac.pl/ksiazka/275712/kartografia-zasady-i-zastosowania-geowizualizacji)*; B. Medyńska-Gulij; 2015
- *Kartografia i geowizualizacja*; B. Medyńska-Gulij; 2021
- *Systemy informacji przestrzennej z QGIS*; cz. I-II; R. Szczepanek; 2017
---
# Notatki
1. Wprowadzenie
	- podstawowe pojęcia
	- systemy informacji przestrzennej
	- modele danych przestrzennych
2. Pozyskiwanie danych
3. Generalizacja kartograficzna
	- generalizacja kartograficzna
	- rodzaje generalizacji kartograficznej
	- generalizacja kartograficzna a etapy opracowywania mapy
4. Metody mapowania
	- metody prezentacji kartograficznej
	- metody znakowe
	- metody pozaznakowe
5. Projektowanie map
---
---
---
---
---
# Definicje z notatek

##### **mapa** (definicja)
>graficzna forma wizualizacji informacji geograficznej wykonana zgodnie z teorią i praktyką kartografii
---

##### **kartografia** (definicja)
>dyscyplina zajmująca się graficznym, komunikacyjnym, wizualno-myślowym i technologicznym opracowaniem informacji przestrzennej na podstawie map oraz innych reprezentacji kartograficznej
---

##### **geomatyka** (definicja)
>dyscyplina zajmująca się pozyskiwaniem, przetwarzanie, gromadzeniem, analizowaniem, i zarządzaniem danymi przestrzennymi w zdefiniowanych układach współrzędnych oraz wizualizacją informacji przestrzennej oraz praktycznym zastosowaniem geoinformacji
---

##### **topografia** (**znaczenie I**) (definicja)
>dziedzina zajmująca się wykorzystywaniem pomiarów obiektów na powierzchni zmieni i rzeźby terenu w celu sporządzenia map topograficznych
---

##### **topografia** (**znaczenie II**) (definicja)
>zespół cech zewnętrznych obejmujących formy rzeźby terenu wraz z elementami krajobrazu naturalnego, antropogenicznego i kulturowego
---

##### **geomedia** (definicja)
>środki przekazu informacji o przestrzeni geograficznej, które twórca wykorzystuje oddzielnie lub wspólnie do jej przekazania bez wywołania działań ruchowych u odbiorcy lub z integracją użytkowania
---

##### **cyfrowy model krajobrazowy** (definicja)
>zapis obiektów w przestrzeni geograficznej w uporządkowaniem strukturze według ich geometrii i atrybutów lub rozumiany jako struktura warstw obiektów przestrzennych z atrybutami i odniesieniem przestrzennym
---

##### **cyfrowe bazy danych przestrzennych** (definicja)
>uporządkowany i zintegrowany zbiór informacji o obiektach w przestrzeni geograficznej zapisany w formacie komputerowym
---

##### **obiektowy model danych** (definicja)
>cyfrowy zapis geometrii i charakterystyki obiektów oraz relacji między nimi
---

##### **dane geometryczne** (definicja)
>dane zawierające informacji o geometrycznym kształcie figury opisującej obiekty
---

##### **struktura warstw** (definicja)
>sposób organizacji plików i folderów
---

##### **model danych przestrzennych** (definicja)
>określenie sposobu reprezentacji obiektów świata rzeczywistego w aspekcie ich położenia przestrzennego, kształtu oraz istniejących między nimi relacji przestrzennych
---

##### **obiekt prosty** (definicja)
>obiekt, którego reprezentacja przestrzenna może być realizowana tylko jednym elementem geometrycznym
---

##### **struktura obiektów**/**obiekt złożony** (**?**) (definicja)
>obiekty tworzące konfiguracje wynikające z ich wzajemnych relacji przestrzennych (topologicznych)
---

##### **wektorowy model danych** (definicja)
>zapis cyfrowy przestrzeni w postaci obiektów punktowych, liniowych, powierzchniowych według ich cech geometrycznych, opierający się na wyznaczeniu lokalizacji punktów według pary współrzędnych prostokątnych płaskich lub współrzędnych geograficznych
---

##### **atrybut elementu rastra** (definicja)
>wartość zapisywana w tablicy dwuwymiarowej (rastrze)
---

##### **numeryczny model terenu** (**NMT**) (**Jerzy Gaździcki 1990**) (definicja)
>*numeryczna reprezentacja powierzchni terenowej utworzonej poprzez zbiór odpowiednio wybranych punktów leżących na jej powierzchni oraz algorytmów interpolacyjnych umożliwiających jej odtworzenie w określonym obszarze*
---

##### **skanowanie** (definicja)
>przekształcenie mapy analogowej do postaci cyfrowego obrazu złożonego z pikseli
---

##### **rozdzielczość skanowania** (definicja)
>liczba pikseli mieszczących się w jednym calu (*dpi*)
---

##### **georeferencjonowanie** (definicja I)
>dodanie do pliku rastrowego odpowiedniej informacji dotyczącej rozdzielczości, rotacji i współrzędnych w celu odpowiedniego wpasowania w dwuwymiarową przestrzeń w zadanym układzie współrzędnych
---

##### **georeferencjonowanie** (definicja II)
>wpasowanie treści kartograficznych w układ współrzędnych poprzez przyporządkowanie określonych wartości współrzędnych odpowiednim punktom na mapie
---

##### **wektoryzacja** (definicja)
>proces przetworzenia treści mapy z formatu rastrowego na wektorowy w określonym układzie współrzędnych
---

##### **rasteryzacja** (definicja)
>proces zamiany modelu wektorowego w rastrowy, zazwyczaj w celu zapisania mapy w formatach rastrowych otwieranych przez większość dostępnych aplikacji
---

##### **atrybutowanie** (definicja)
>zapisywanie informacji o obiektach, która jest przechowywana integralnie z danymi geometrycznymi modelu rastrowego lub wektorowego
---

##### **generalizacja kartograficzna** (definicja)
>sposób doboru i uogólnienia treści bazy danych lub mapy polegający na celowym wyjawieniu i wyodrębnieniu istotnych, typowych cech i charakterystycznych właściwości przedstawianych obiektów, zjawisk i faktów tworzących naukowo uzasadniony czasoprzestrzenny model danych geograficznych zgodnie z jego przeznaczeniem
---

##### **forma mapy** (definicja) (**???**)
>struktura modelu stosunków przestrzennych w sensie lokalizacyjnym, a więc w układzie *x*, *y* mapy
---

##### **mapować** (**SJP**) (definicja I)
>*przyporządkowywać zasoby systemowe do innych, zwykle wirtualnych*
---

##### **mapować** (**SJP**) (definicja II)
>*tworzyć schemat czegoś, np. jakiegoś zjawiska*
---

##### **mapować** (**SJP**) (definicja III)
>*oznaczać na mapie szczegóły terenu na podstawie materiałów uzyskanych z pomiarów lub materiałów źródłowych; kartować*
---

##### **sygnatura** (definicja)
>znaków umownych zwartych graficznie
---

##### **zasięg** (**PWN 1989**) (definicja)
>*granica sięgania, rozprzestrzeniania się czegoś, największa odległość na jaką coś dociera, coś się rozciąga, ..., obszar czymś objęty*
---

##### **waga kropki** (definicja)
>liczba elementów, której odpowiada znak w kropkowej metodzie prezentacji kartograficznej
---

##### **kartogram**/**mapa choropletowa** (definicja)
>mapa statystyczna prezentująca średnią intensywność zjawiska w granicach pól odniesienia, na które podzielono obszar
---

##### **punkt cechowany** (definicja)
>znak punktowy (kropka lub prosta figura geometryczna), którego opis odnosi się do charakterystyki liczbowej powierzchni rzeczywistej lub statystycznej prezentowanej w postaci zbioru punktów cechowanych
---

##### **izolinia** (definicja)
>linia łącząca na mapie punkty o jednakowej wartości liczbowej danego zjawiska
---

##### **wysokość warstwowa** (definicja)
>różnica wysokości między sąsiednimi warstwicami
---

##### **design kartograficzny** (definicja)
>proces twórczy mentalnego wyobrażania mapy i fizycznego graficznego jej tworzenia
---

##### **projektowanie map** (definicja)
>proces obejmujący etapy graficznego redagowania obrazu kartograficznego - od koncepcji, przez przygotowanie i wykonawstwo do publikacji
---

##### **kompozycja mapy** (definicja)
>zaplanowanie rozmieszczenia części zasadniczych mapy na płaszczyźnie arkusza i zarządzenie hierarchią wizualną
---

##### **deseń kartograficzny** (definicja)
 >wzór znaków graficznych powtarzających się w regularny sposób na określonej powierzchni
---

##### **synteza addytywna** (definicja)
>zjawisko mieszania barw poprzez sumowanie wiązek światła widzialnego różnych długości
---

##### **synteza subtraktywna** (definicja)
>zjawisko mieszania barw poprzez odejmowanie wiązek światła widzialnego różnych długości
---

---
