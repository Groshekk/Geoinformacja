---
przedmiot: Mapy tematyczne
date_zajec: 15.01.2024
rodzaj_zajec: laboratorium
prowadzacy: Cezary Kaźmierowski
date: 16.01.2024
type: notatki
tags: notatki, geoinformacja, studia, IIrok
---

# Mapy tematyczne; 15.01.2024
**Czynniki glebotwórcze**

---
# Czynniki glebotwórcze
##### gleba (definicja I)
>trójwymiarowy utwór naturalny występujący w wierzchniej warstwie skorupy ziemskiej, powstały ze zwietrzeliny skalnej w wyniku oddziaływania na tę zwietrzelinę organizmów żywych i czynników klimatycznych w określonych warunkach reliefu; czynnikiem modyfikującym jej kształtowanie jest pasterska, rolnicza, urbanizacyjna i przemysłowa działalność człowieka
---
##### gleba (definicja II)
>nagromadzenie części mineralnych i organicznych, pochodzących z wietrzenia lub akumulacji, naturalnej lub antropogenicznej, które ma zdolność zaopatrywania organizmów żywych w wodę i składniki pokarmowe, będące częścią litosfery lub trwale powiązane z litosferą za pośrednictwem budynków lub budowli
---
#### struktura gleby
- solum
- profil glebowy
- profil zwietrzelinowy
- regolit
---
- struktura pedologiczna
- struktura pedologiczna i litologiczna
- struktura litogeniczna - utlenienie, oglejenie, uwalnienie, połączenie
- struktura litogeniczna - brak zmian, brak utlenienia, brak połączeń
- lita skała/osad
- wody podziemne
---
- **O**
- **A**
- **E**
- **EB**/**BE**
- **BC**/**CB**
- **C**
- **CD**/**DC**
- **D**
- **R**
- ***aquifer***
---
#### czynniki glebotwórcze (**Dokuczajew 1886**)
- **klimat**
	- opady atmosferyczne
	- temperatura
- **warunki wodne**
	- woda płynąca
	- woda gruntowa
- **rzeźba terenu**
	- wysokość
	- nachylenie
	- ekspozycja
- **działalność człowieka**
	- działalność bezpośrednia
	- działalność pośrednia
	- działalność pozytywna
	- działalność negatywna
- **czas**
	- wiek bezwzględny
	- wiek względny
- **materiał macierzysty**
	- skład mineralny
	- właściwości fizyczne
	- właściwości chemiczne
- **organizmy żywe**
	- rośliny (fitoedafon)
	- organizmy wyższe (zooedafon)
---
###### *factors od soil formation* (**H. Jenny 1941**)
$$S = f(cl,\ o,\ r,\ p,\ t)$$
- ***S*** - gleba (*soil*)
- ***cl*** - klimat (*climate*)
- ***o*** - organizmy (*organism*)
- ***r*** - ukształtowanie terenu (*relief*/*terrain*)
- ***p*** - *parent material*
- ***t*** - czas (*time*)
---
#### krajobraz gelbowy
- krajobraz glebowy
	- polipedon
		- pedon
---
#### właściwości gleby kształtowane przez materiał macierzysty
- podatność na wietrzenie
- szybkość formowania profilu glebowego
- zawartość frakcji ilastej (struktura, pojemność sorpcyjna)
- retencja wodna, natlenienie
- przewodność hydrauliczną
- odczyn, trwałość odczyna
- zasobność w składniki odżywcze
- mikroklimat glebowy - aktywność biologiczna
- warunki siedliskowe dla zbiorowisk roślinnych
---
##### uziarnienie (definicja)
>stan rozdrobienia składników mineralnych
---
#### rozwój gleb strefowych w Polsce
- osady **drobnoziarniste**
	- gleba inicjalna → gleba rdzawa
- osady **gruboziarniste**
	- gleba inicjalna → gleba brunatna → gleba płowa
---
#### wpływ warunków klimatycznych
- wpływ **bezpośredni**
	- temperatura powietrza
	- temperatura gleby
	- erozja
	- wietrzenie
	- formowanie profilu
	- wymywanie
	- zasolenie
	- pustynnienie
- wpływ **pośredni**
	- rozwój roślinności (**NPP**)
	- produktywność składników
	- produktywność wody
	- cykl hydrologiczny
	- bilans energii
	- cykle biochemiczne
	- uwalnianie/wiązanie węgla w glebie
---
#### wpływ gleby na klimat
- wpływ **bezpośredni**
	- albedo
	- bilans energii
	- bilans wodny
	- procesy mikrobiologiczne
- wpływ **pośredni**
	- wzrost roślin
	- cykl biochemiczny wody (**H<sub>2</sub>0**)
	- cykl biochemiczny węgla (**C**)
	- cykl biochemiczny azotu (**N**)
	- cykl biochemiczny fosforu (**P**)
	- cykl biochemiczny siarki (**S**)
---
#### okresy klimatyczne holocenu (**Mangerud *et al.* 1974**)
- **10 000 - 9 000 <sup>14</sup>C BP** - okres preborealny
- **9 000 - 8 000 <sup>14</sup>C BP** - okres borealny (zimno, sucho, coraz cieplej)
- **8 000 - 5 000 <sup>14</sup>C BP** - okres atlantycki (ciepło, wilgotno)
- **5 000 - 2 500 <sup>14</sup>C BP** - okres subborealny (oziębienie, potem cieplej)
- **2 500 - <sup>14</sup>C BP** - okres subatlantycki
---
##### mikoryza (definicja)
>symbioza korzeni roślin z dopasowanymi do nich grzybami
---
#### wpływ rzeźby terenu na kształtowanie gleb
- wpływ **bezpośredni**
	- kształtowanie lokalnego klimatu
	- kształtowanie stosunków wodnych, gospodarki wodnej - głębokość wody, warunki drenażu, redystrybucja opadu
	- kształtowanie pokrywy roślinnej
	- lokalne determinowanie zróżnicowania pokrywy glebowej
- wpływ **pośredni**
	- bilans energii
	- permanentne utrzymywanie procesu glebotwórczego w fazie inicjalnej - grawitacyjne zsuwanie się zwietrzeliny w dół stoku
---
#### rodzaje gleb (**wiek względny**)
- gleba **młoda** - początkowa faza rozwoju
- gleba **dojrzała** - klasycznie rozwinięty profil glebowy; gleba klimaksowa
- gleba **stara** - silnie zwietrzała, strefa tropikalna
---
##### gleba kopalna (definicja)
>gleba lub w przypadku ich ogłowienia tylko ich dolne poziomy utworzone w przeszłości, a następnie odcięte od bezpośrednich wpływów czynników glebotwórczych przez przykrycie osadami różnej miąższości i genezy (np. deluwialnymi, eolicznymi, antropogenicznymi)
---
##### gleba ekshumowana (definicja)
>gleba, która w przeszłości była przez pewien czas przykryte osadami (były glebami kopalnymi), a następnie zostały odsłonięte
---
##### gleba reliktowa (definicja)
>gleba, która powstała w przeszłości, w odmiennym od dzisiejszego układzie czynników glebotwórczych, a występujące na współczesnej powierzchni terenu
---
#### degradacyjny wpływ rolniczego użytkowania gleby
- wzrost udziału mikroagregatów
- powstawanie twardych brył
- wzrost gęstości
- formowanie się podeszwy płużnej
- spadek porowatości
- spadek pojemności wodnej
- spadek aeracji
- spłycanie profilu
- spadek próchniczności
- obniżenie zawartości składników, zawężanie stosunków *C : N : P*
- zakwaszenie
- obniżenie **CEC**
- wzrost stężenia glinu (**Al**)
- obniżenie bioróżnorodności
- spadek aktywności biologicznej
---
#### działalność człowieka a proces glebotwórczy
- wycinanie lasów (szczególnie na glebach piaszczystych) → silna erozja → gleby **inicjalne**, gleby **słabo wykształcone** (nieużytki)
- zdrenowanie gleb gruntowo-glejowych → hamowanie procesów glejowych → proces brunatnienia → gleby **brunatne**
- odwodnienie torfowisk → gleby **murszowo-torfowe**
- intensywne nawożenie, głęboka orka, odwodnienie, nawodnienie → gleby **antropogeniczne**
- rekultywacja wyrobisk, hałd pokopalnianych → zwiększenie terenów zalesionych, zakrzaczonych, zadarnionych
---
#### zjawiska procesu glebotwórczego
- wymiana materii, przepływ energii
- przemiana składników mineralnych
- transformacja materii organicznej
- translokacja składników w profilu glebowym
- wytrącanie produktów rozkładu
---
#### procesy wietrzenia fizycznego
- **insolacja** - dezintegracja blokowa, dezintegracja granularna, eksfoliacja spowodowana naprzemiennym nagrzewaniem i ochładzaniem
- **kongelacja**/**zamróz** - zmienianie się objętości wody zamarzającej w szczelinach; wapienie, skały fliszowe
- **eksudacja** - mechaniczne oddziaływanie soli krystalizujących się w porach; piaskowce
- **deflokulacja** - niszczenie spoistości skał ilastych spowodowane zmianami wilgotności; łupki ilaste
- **wietrzenie z udziałem organizmów** - oddziaływanie naprężeń rozrastających się korzeni
---
#### formy wietrzenia
- **rozpuszczanie**
- **hydratacja**/**uwodnienie** - przyłączanie cząsteczek wody; hematyt w getyt
- **hydroliza** - najpowszechniejszy proces; glinokrzemiany pierwotne (skalenie, miki); w klimacie umiarkowanym z ortoklazu powstaje kaolinit, w obecności **CO<sub>2</sub>** illit
- **karbonatyzacja** - powstawanie węglanów; **CO<sub>2</sub>** w powietrzu rozpuszcza się w opadach atmosferycznych, reaguje z tlenkami żelaza, krzemianami
- **utlenianie** - reagowanie z tlenem minerałów zawierających żelazo (**Fe**), siarkę (**S**), mangan (**Mn**)
- **redukcja** - związane z aktywnością mikroorganizmów (oglejenie)
---
### Procesy glebotwórcze
#### procesy glebotwórcze
- proces inicjalny
- proces darniowy
- proces bielicowania
- proces rdzawienia
- proces brunatnienia
- proces płowienia
- proces glejowy
- proces torfienia
- proces murszenia
- procesy zasolenia
	- proces salinizacji
	- proces sołonizacji
	- proces sołodyzacji
- proces ferralizacji/proces latetzacji
---
#### proces inicjalny
- przejście od wietrzenia do procesów glebotwórczych
- udział pionierskich zbiorowisk organizmów - mikroorganizmy, porosty, mchy
- stopniowe zasiedlanie wietrzejących materiałów macierzystych przez coraz bardziej wymagające organizmy
- stopniowo akumulacja resztek organicznych
- rozwój biologicznego obiegu pierwiastków
- przekształcenie górnej części materiału macierzystego w glebę
- skutkuje powstaniem gleby początkowego stadium rozwoju - **gleba inicjalna**
---
#### proces darniowy
- dominacja procesów biologicznych
- materiały macierzyste zasobnych w kationy zasadowe, węglan wapnia, frakcję iłową (lessy, gliny, pyły, zwietrzeliny skał zasadowych) pod roślinnością trawiastą
- wytwarzani dużej ilości biomasy (20-30 Mg/ha/40-60 Mg/ha)
- formowanie struktury gruzełkowatej poprzez cykliczny rozwój korzeni
- sukcesywna akumulacja węgla organicznego w poziomie akumulacyjno-próchniczym poprzez rozkład biomasy - formowanie poziomu ***mollik***
- typowy proces glebotwórczy dla **czarnoziemów**
---
#### proces bielicowania
- utwory kwaśne, ubogie w składniki odżywcze o dużej przepuszczalności (piaski wydmowe, sandry dalekiego transportu, piaski dolinne, zwietrzeliny granitoidów, kwarcytów, piaskowców) pod lasami iglastymi
- tworzenie w górnej części rozpuszczalnych połączeń (chelaty) przez kwasy fulwowe przy małej zawartości związków żelaza, glinu
- translokacja w głąb rozpuszczalnych połączeń (cheaty) przy jednoczesnym przyłączaniu kolejnych cząstek żelaza, glinu do utraty rozpuszczalności
- formowanie poziomu eluwialnego ***Es albik*** w strefie wymywania - jasne/prawie białe zabarwienie
- formowanie się poziomu iluwialnego ***BS spodik*** w strefie akumulacji
---
#### proces rdzawienia
- utwory piaszczyste różnej genezy (piaski sandrowe bliskiego transportu, piaski zwałowe, piaski terasowe, utwory piaszczyste słabo przesortowane, mało przemyte) borami mieszanymi, lasami mieszanymi
- wietrzenie krzemianów, glinokrzemianów
- formowanie nierozpuszczalnych kompleksów półtoratlenków żelaza, glinu z próchnicą (**R<sub>2</sub>O<sub>3</sub>**) - kompleksy próchniczno-żelazisto-glinowe
- wytrącanie się kompleksów próchniczno-żelazisto-glinowych, wolnych tlenków żelaza, glinu na ziarnach mineralnych w formie otoczek o rdzawym zabarwieniu
- nieruchliwość kompleksów próchniczno-żelazisto-glinowych - duże nagromadzenie (**R<sub>2</sub>O<sub>3</sub>**), mała ilość rozpuszczalnych frakcji kwasów humusowych (fulwowych) uniemożliwia formowanie się rozpuszczalnych cheat
---
#### proces brunatnienia
- materiały macierzyste zasobne w składniki odżywcze (gliny, lessy, pyły, zwietrzeliny skał kwaśnych) pod wielogatunkowymi lasami liściastymi
- intensywne wietrzenie glinokrzemianów prowadzące do uwalniania związków żelaza przy udziale produktów rozkładu materii organicznej
- formowanie trwałych kompleksów próchniczno-ilasto-żelazistych przez uwolnione tlenki żelaza, glinu, wodorotlenki żelaza, glinu
- nieruchliwość kompleksów próchniczno-ilasto-żelazistych - akumulacja *in situ*
- kompleksy próchniczno-ilasto-żelaziste pokrywają cząstki gleby - zabarwienie brunatne
- formowanie struktury pedogenicznej - formowanie poziomu ***cambik*** (***Bw***)
---
#### proces płowienia (*lessivage*)
- pionowa translokacja frakcji ilastej w głąb profilu glebowego - poziomy wymywania ***A***, ***Et luvik*** → poziom wmywania ***Bt argik***
- lekko kwaśny odczyn
- spiaszczenie górnej części profilu glebowego
- formowanie się dwuczłonowości uziarnienia gleby
---
#### proces glejowy
- redukcja w warunkach beztlenowych przy udziale mikroorganizmów, oddychania beztlenowego - redukcja żelaza trójwartościowego (brunatno-rdzawego) do formy dwuwartościowej (niebieskawe, zielonkawe, popielate)
- formowanie cech oglejenia - ***Bg**, **Etg**, **Cg***
- formowanie poziomu glejowego *G*
- formy (**geneza**):
	- forma gruntowo-glejowa
	- forma opadowo-glejowa
---
#### proces torfienia
- gromadzenie szczątków roślinnych w procesie paludyzacji - warunki nadmiernego uwilgotnienia (anaerobiozy)
- utwór torfowy mułowy → **gleba mułowa**, **gleba torfowa i mułowa**
- poziom ***histic*** (***O***) diagnostyczny dla gleb powstających w procesie torfienia - charakterystyczna struktura gąbczasta/włóknista
---
#### proces murszenia
- odwadniane gleby torfowe, mułowe - warunki aerobowe
- fizyczne, fizykochemiczne, mikrobiologiczne przemiany utworów organicznych - kurczenie, pękanie, mineralizacja, formowanie coraz mniejszych agregatów z masy organicznej
- zanikanie włóknisto-gąbczastej struktury torfu
- formowanie agregatów o różnych rozmiarach, kształtach przez połączenia próchniczne
- coraz drobniejsze i twardsze agregaty przy wzroście nasilenia mineralizacji
- poziom murszowy (***murshic***) powierzchniowym poziomem objętym murszeniem
- poziom murszowy (***murshic***) diagnostyczny dla **gleb murszowych** (***rząd Organiczne***), **gleb murszowatych** (***rząd Czarnoziemne***)
---
#### proces salinizacji
- egzoperkolatywna gospodarka wodna w klimacie aridowym
- odparowywanie silnie zmineralizowanych wód - akumulacja soli (**Ca**, **Mg**, **Na**, **K**)
- formowanie **gleby słonej** - **sołończak**
- poziom ***salic***
- halofity jako roślinność porastająca
---
#### proces sołonizacji/alkalizacja/sołońcowanie
- większa ilość opadów umożliwia wymywanie soli **Ca**, **Mg** z wierzchnich poziomów
- dominacja sodu na wierzchnich poziomach umożliwia silną dyspersję, migrację w głąb koloidów mineralnych, organicznych
- formowanie przy *pH* *>8,5* **sołońców** (czarne gleby alkaliczne) z poziomem ***natric***  o strukturze kolumnowej - zmiany wilgotności prowadzące do zmian objętości minerałów ilastych
---
#### proces sołodyzacji
- okresowo przemywna gospodarka wodna w klimacie semiaridowymi, semihumidowym
- obniżenie *pH*
- silniejsze wymywanie
- strefa zdyspergowanej próchnicy, minerałów ilastych (poziom ***natric***) głębsza niż w sołońcach
- formowanie **sołodzi** ze stropami kolumn jaśniejszymi od dołu
---
#### proces ferralizacji/proces latetzacji
- stare powierzchnie lądowe w gorącej, wilgotnej strefie tropikalnej zbudowanych ze skał kwaśnych pod roślinnością wilgotnych wielopiętrowych lasów tropikalnych o dużej bioróżnorodności
- formowanie czerwonożółtych oraz czerwonych **gleb ferralitowych**/**gleb laterytowych** (***ferralsoli***)
- hydroliza pierwotnych, większości wtórnych glinokrzemianów, kwarcu
- głębokie wmywanie w strefę wietrzenia **Si**, **Al**, **Fe**, **Mg**, **Ca**, **K**
- wolniejsze wmywanie żelaza, glinu z ich akumulacją w profilu glebowym
- formowanie poziomu ***ferralic*** - grubsze ziarna kwarcu, wtórne minerały ilaste o małej aktywności (kaolinit), wtórne tlenki żelaza getyt (barwa żółta), hematyt (barwa czerwona), tlenki glinu (gibbsyt)
- wytrącanie związków żelaza z wody gruntowej przy płytszym jej zaleganiu  - formowanie poziomu ***plintyt***, gleby ***plintosol***
---
