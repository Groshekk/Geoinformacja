---
przedmiot: Mapy tematyczne
date_zajec:
rodzaj_zajec:
prowadzacy: Lech Kaczmarek
date: 09.12.2023
type: notatki
tags: notatki, geoinformacja, studia, IIrok
---

# Program wykładów
1. Środowisko przyrodnicze a geograficzne
2. Mapa tematyczna - pojęcie, treść
3. Poziomy ujęcia atrybutów w kartografii i geoinformacji
4. Mapa tematyczna - sposób udostępniania
5. Uwarunkowania prawne tworzenia map tematycznych
6. Współczesne zasoby danych tematycznych
	1) **GUGiK**, Urząd Marszałkowski, **PODGiK**
	2) Państwowy Instytut Geologiczny
	3) dane glebowe
	4) Wody Polskie
	5) Lasy Państwowe
	6) gospodarka przestrzenna
	7) **GDOŚ**
	8) **GIOŚ**
	9) **GUS**
	10) inne
7. Jakość danych tematycznych
---
# Bibliografia
- *Mapy tematyczne*; Wiesława Żyszkowska, Waldemar Spallek, Dorota Borowicz; Warszawa: PWN.
- *Praktyczne aspekty ocen środowiska przyrodniczego*; S. Bródka, 2010; Poznań: Wydawnictwo Naukowe Bogucki.
- *Potencjał informacyjny krajowych baz danych przestrzennych w kartograficznych badaniach środowiska przyrodniczego*; Lech Kaczmarek; 2013; Poznań: UAM.
- *GIS - obszar zainteresowań*; D. Gotlib, A. Iwaniak, R. Olszewski; 2007; Warszawa: PWN.
- *Przyrodnicze podstawy gospodarowania przestrzenią*; A. Macias, S. Bródka; 2014; Warszawa: PWN.
---
# Notatki
## Notatki z wykładów
1. Wprowadzenie
2. Atrybuty. Udostępnianie. Regulacje prawne
3. Gleby a produkcja żywności. Kartografia gleb
4. Zasoby danych tematycznych
5. Mapy tematyczne GUGiK
6. Mapy tematyczne PIG
7. ISOK
8. BDL, planowanie przestrzenne, GDOŚ, GIOŚ, jakość danych
---
## Notatki z laboratoriów
4. Czynniki glebotwórcze
---
---
---
---
---
# Definicje z notatek
##### **mapa** (definicja)
>graficzny obraz powierzchni Ziemi przedstawiony w zmniejszeniu w sposób określony matematycznie, uogólniony i umowny
---

##### **bioróżnorodność**/**różnorodność biologiczna** (***Konwencja o różnorodności biologicznej* 1992**) (definicja)
>zmienność żywych organizmów zamieszkujących wszystkie środowiska oraz zmienność systemów ekologicznych, których częścią są te organizmy, przy czym tak ujęta zmienność obejmuje różnorodność wewnątrzgatunkową, międzygatunkową i różnorodność ekosystemów
---

##### **gleba** (definicja **I**)
>nagromadzenie części mineralnych i organicznych, pochodzących z wietrzenia lub akumulacji, naturalnej lub antropogenicznej, które ma zdolność zaopatrywania organizmów żywych w wodę i składniki pokarmowe, będące częścią litosfery lub trwale powiązane z litosferą za pośrednictwem budynków lub budowli
---

##### **gleba** (definicja **II**)
>trójwymiarowy utwór naturalny występujący w wierzchniej warstwie skorupy ziemskiej, powstały ze zwietrzeliny skalnej w wyniku oddziaływania na tę zwietrzelinę organizmów żywych i czynników klimatycznych w określonych warunkach reliefu; czynnikiem modyfikującym jej kształtowanie jest pasterska, rolnicza, urbanizacyjna i przemysłowa działalność człowieka
---

##### **zasoby glebowe** (definicja)
>powierzchnia skalowana wielkością plonu lub wskaźnikiem produktywności  - średni plon i łączna produkcja
---

##### **sprężystość gleby** (definicja)
>zdolność gleby do regeneracji po jej degradacji
---

##### **kartografia gleb** (definicja)
>dział gleboznawstwa zajmujący się realizacją badań karograficzno-gleboznawczych oraz opracowywaniem map glebowych i map pochodnych
---

##### **mapa glebowa** (definicja)
>graficzne przedstawienie przestrzennego zróżnicowania pokrywy glebowej na płaszczyźnie za pomocą znaków umownych zgodnie z obowiązującymi  zasadami kartografii
---

##### **katena** (definicja) (**Marcinek, Komisarek 1991**)
>układ i sekwencja wzdłuż stoku gleb powiązanych ze sobą całokształtem procesów glebotwórczych i wietrzenia, a także translokacji produktów wietrzenia wraz z wodami powierzchniowymi i podpowierzchniowymi
---

##### **konsocjacja** (definicja)
>okonturowana powierzchnia w obrębie, której ponad 50% pedonów należy do taksonu nadającego nazwę, co najmniej 25% pedonów jest podobna do jednostki wiodącej, natomiast odrębne morfologicznie glebowe inkluzje stanowią mniej niż 25% powierzchni okonturowanej jednostki
---

##### **kompleks** (definicja)
>okonturowana powierzchnia zbudowana z dwu lub więcej różnych taksonów lub grup jednostek nierozdzielanych, występujących w regularnych i zdefiniowanych układach przestrzennych, nie mogą być jednak wyodrębnione w danej skali mapy; udział inkluzji gleb odrębnych od wiodących jest mniejszy niż 25%
---

##### **asocjacja** (definicja)
>okonturowana powierzchnia zbudowana z dwu lub więcej taksonów, których wielkość pozwala na ich samodzielne wyodrębnienie w skali większej niż *1:25 000*, przy udziale inkluzji mniejszy niż 25%; składowe asocjacji tworzą powtarzalne struktury przestrzenne, jednak nie można ich wyróżnić na mapach średniokalowych i małoskalowych
---

##### **jednostka nierozdzielna** (definicja)
>wydzielenie składające się z kilku taksonów, o podobnym czynniku ograniczającym użytkowanie (np. stromość, regularne zalewy, skalistość)
---

##### **jednostka różna** (definicja)
>wydzielenie składające się z różnej liczby taksonów, o różnej budowie, przydatności i położeniu w krajobrazie, a które nie są dostatecznie poznane; stosowane są na mapach w bardzo małych skalach
---

##### **uziarnienie** (definicja)
>stan rozdrobienia składników mineralnych
---

##### **mikoryza** (definicja)
>symbioza korzeni roślin z dopasowanymi do nich grzybami
---

##### **gleba kopalna** (definicja)
>gleba lub w przypadku ich ogłowienia tylko ich dolne poziomy utworzone w przeszłości, a następnie odcięte od bezpośrednich wpływów czynników glebotwórczych przez przykrycie osadami różnej miąższości i genezy (np. deluwialnymi, eolicznymi, antropogenicznymi)
---

##### **gleba ekshumowan**a (definicja)
>gleba, która w przeszłości była przez pewien czas przykryte osadami (były glebami kopalnymi), a następnie zostały odsłonięte
---

##### **gleba reliktowa** (definicja)
>gleba, która powstała w przeszłości, w odmiennym od dzisiejszego układzie czynników glebotwórczych, a występujące na współczesnej powierzchni terenu
---

##### **jakość danych** (**ISO**) (definicja)
>*kompleksowy zespół cech i charakterystyk zbiorów danych, które wpływają na możliwość zaspokojenia przez ten zbiór wymagań użytkowników*
---

---
---
---
---
---
