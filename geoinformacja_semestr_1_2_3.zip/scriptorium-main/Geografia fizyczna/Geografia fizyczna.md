---
przedmiot: Geografia fizyczna
date_zajec:
rodzaj_zajec: wykład
prowadzacy: Małgorzata Mazurek, Alfred Stach

date: 31.08.2023
type: notatki
tag: notatki, geoinformacja, studia, Irok
---

# Kolokwia cząstkowe
## I kolokwium cząstkowe (**27.10.2022**)
- obszary badań geografii fizycznej
- skutki systemu zamkniętego Ziemi
- hipoteza naukowa
- czynniki sprzyjające życiu w kosmosie
- geneza Księżyca
---
## II kolokwium cząstkowe (**24.11.2022**)
- schemat globalnej cyrkulacji atmosfery
- skutki zachodzenia zjawiska spirali Ekmana na równiku
- zwiększony transport ciepła w oceanie względem transportu w atmosferze
- rodzaje wód w strefie aeracji
- warunki konieczne do powstania lodowca
---
## III kolokwium cząstkowe (**15.12.2022**)
- skład chemiczny Ziemi
- obszary koncentracji wulkanizmu i trzęsień ziemi
- metody badania wnętrza Ziemi
- wschodnie prądy morskie
- schemat prądu geostroficznego
---
# Notatki
1. Historia geografii
	  - postacie
	  - człowiek a środowisko
	  - definicje
2. Metoda naukowa
    - wprowadzenie
    - model
    - geneza Księżyca
3. Środowisko przyrodnicze. Prawa geografii
    - geografia fizyczna
    - środowisko przyrodnicze
    - prawo jedności przyrody
    - teoria ogólna systemów
4. Powstanie Układu Słonecznego
    - kosmologia
    - powstanie Układu Słonecznego
    - struktura Układu Słonecznego
5. Geogeneza. Biogeneza
    - chronometria
    - planety pozasłoneczne
    - powstanie Ziemi
    - życie w kosmosie
    - życie na Ziemi
6. Energia słoneczna. Energia geotermalna
7. Sprzężenie. Atmosfera
    - sprzężenie zwrotne
    - atmosfera
    - węgiel a atmosfera
    - domieszki w atmosferze
8. Hydrosfera
    - woda
    - woda na Ziemi
    - wody podziemne
9. Hydrografia. Kriosfera
    - rzeka
    - jezioro
10. Cyrkulacja atmosferyczna
    - cyrkulacja atmosferyczna
    - wiatry
    - strefy klimatyczne
11. Wszechocean
12. Cyrkulacja oceaniczna
    - właściwości wody a prądy morskie
    - mechanizm spirali Ekmana
    - rozkład przestrzenny prądów morskich
    - cyrkulacja termohalinowa
    - badanie cyrkulacji oceanicznej
13. Globalny obieg wody
14. Litosfera
    - struktura litosfery
    - cykl skalny
    - tektonizm
15. Pierwiastki. Cykle krążenia materii
16. Mineralogia. Petrologia
17. Wietrzenie. Geomorfologia
    - wietrzenie "ogólne"
    - wietrzenie fizyczne
    - wietrzenie chemiczne
    - wietrzenie biologiczne
    - procesy geomorfologiczne
    - procesy stokowe
    - erozja
- Ćwiczenia
    - tematy i szczegółowe zagadnienia
    - notatki
---
# Definicje z notatek

##### **geografia** (definicja)
> nauka o powłoce ziemskiej, jej przestrzennemu zróżnicowaniu przyrodniczym i społeczno-ekonomicznym, oraz o związkach zachodzących między zjawiskami w jej obrębie
---

##### **modelowanie** (definicja)
> tworzenie modelu
---

##### **symulacja** (definicja)
> wykorzystywanie modelu
---

##### **symulacja** (**Banks 1998**) (definicja)
> *naśladowanie zmian w czasie działania zjawisk świata rzeczywistego lub systemu*
---

##### **symulacja** (**Velten 2009**) (definicja)
> *stosowanie modelu w celu rozwiązywania postawionego problemu i podania odpowiedzi na pytanie odnoszące się do badanego systemu*
---

##### **symulacja** (**Fritzson 2004**) (definicja)
> *eksperyment przeprowadzany na modelu*
---

##### **retrodykcja** (definicja)
>określenie przeszłej ścieżki rozwoju kończącej się aktualnym stanem
---

##### **predykcja** (definicja)
>przewidywanie
---

##### **zrównoważony rozwój** (*sustainable development*) (definicja)
>koncepcja rozwoju integrująca jednakowo: wzrost gospodarczy, rozwój społeczny, poszanowanie środowiska przyrodniczego; nieograniczający możliwości rozwoju przyszłych pokoleń
---

##### **geografia fizyczna** (definicja)
>nauka badająca całą powierzchnię Ziemi i jej poszczególnych struktur pod względem składu materialnego, budowy, rozwoju, rozczłonkowania terytorialnego; w ujęciu globalnym i w odpowiednich jednostkach przestrzennych z uwzględnieniem działalności człowieka
---

##### **noosfera** (definicja)
>sfera ludzkiego rozumu
---

##### **środowisko przyrodnicze** (definicja)
>zespół komponentów biotycznych, abiotycznych, powiązanych przepływem energii i wymianą materii, oddziałujących wzajemnie na siebie
---

##### **system** (definicja I)
>wyidealizowane, zgeneralizowane przedstawienie rzeczywistości
---

##### **system** (definicja II)
>zbiór elementów, obiektów, zjawisk znajdujących się w określonych relacjach między sobą i otoczeniem w taki sposób, że stanowią one całość... do funkcjonowania w określony sposób
---

##### **planetozymal**/**planetezymal** (definicja)
>zarodek planety, powstający przez skupianie się zderzającej się ze sobą materii
---

##### **ekosfera**/**strefa zamieszkiwalna**/***habitable zone*** (**HZ**) (definicja)
>strefa wokół gwiazd, w obrębie której na planetach znajdujących się w niej się znajdujących mogą panować fizyczne i chemiczne warunki umożliwiające powstanie, rozwój i utrzymanie się organizmów żywych, w tym istnienie ciekłej wody
---

##### **wiatr słoneczny** (definicja)
>wypływający z gwiazdy strumień plazmowy składający się głównie z protonów, elektronów, cząstek alfa
---

##### **atmosfera** (definicja)
>utrzymywana przez grawitację gazowa powłoka otaczająca siało niebieskie
---

##### **bilans energetyczny** (definicja)
>bilans energii określony przez strumień promieniowania słonecznego padającego i odbijanego przez atmosferę oraz przez strumień promieniowania długofalowego emitowanego przez powierzchnię i atmosferę
---

##### **pojemność cieplna** (definicja)
>ilość energii potrzebna do podniesienia temperatury o 1K/1°C
---

##### **albedo** (definicja)
>stosunek promieniowania odbitego do promieniowania całkowitego podającego na powierzchnię w skali od 0 (brak odbicia) do 1 (całkowite odbicie)
---

##### **konwekcja** (definicja)
>proces przekazywania ciepła przez makroskopowy ruch materii w gazie, cieczy, plazmie
---

##### **prąd konwekcyjny** (definicja)
>ruch materii związany z różnicami temperatur prowadzący do przenoszenia ciepła
---

##### **adwekcja** (definicja)
>przekazywanie ciepła przez ruch ciała (np. w wulkanizmie)
---

##### **regulacja** (definicja)
>oddziaływanie na proces w celu zmniejszenia odchyleń od jego pożądanego przebiegu (istnienie sprzężeń zwrotnych)
---

##### **sprzężenie zwrotne** (definicja)
>seria zdarzeń, gdy jedna zmiana stanowi przyczynę innej, która z kolei oddziałuje przez strukturę systemu na zmianę pierwotną (efekt akcji cyrkulacyjnej)
---

##### **domieszka atmosfery** (definicja)
>składnik atmosfery zmienny w czasie i przestrzeni
---

##### **aerozole atmosferyczne** (definicja)
> krople lub stałe cząsteczki pochodzenia naturalnego lub antropogenicznego (tlenki siarki, tlenki azotu)
---

##### **porowatość gruntu** (definicja)
>stosunek objętości porów w próbce materiału porowatego do całkowitej objętości próbki
---

##### **wodoprzepuszczalność** (definicja)
>zdolność gruntu, skał do przepuszczania wody pod wpływem grawitacji
---

##### **pojemność wodna** (definicja)
>ilość wody jaką może wchłonąć skała, grunt
---

##### **dolina rzeczna** (definicja)
>podłużne obniżenie terenu o wyraźnym spadku podłużnym
---

##### **wiatr** (definicja)
>wywołany różnicą ciśnień poziomy ruch powietrza w niższej warstwie troposfery przemieszczający się od ciśnienia wyższego (wyż) do ciśnienia niższego (niż)
---

##### **ciśnienie atmosferyczne** (definicja)
>nacisk słupa powietrza na powierzchnię Ziemi
---

##### **termoklina** (definicja)
>warstwa wody, w której następuje szybka zmiana **temperatury** wraz ze wzrostem głębokości
---

##### **haloklina** (definicja)
>warstwa wody, w której następuje szybka zmiana **zasolenia** wraz ze wzrostem głębokości
---

##### **pyknoklina** (definicja)
>warstwa wody, w której następuje szybka zmiana **gęstości** wraz ze wzrostem głębokości
---

##### **zlewnia** (definicja)
>obszar, z którego wody spływają do jednego obiektu hydrograficznego
---

##### **dorzecze** (definicja)
>obszar, z którego wody spływają do jednego systemu rzecznego
---

##### **minerał** (definicja)
>pierwiastek lub związek chemiczny będący normalnie ciałem krystalicznym, którego struktura ukształtowała się w toku procesów geologicznych lub kosmicznych w sposób naturalny, bez ingerencji człowieka
---

##### **stan krystaliczny** (definicja)
>uporządkowane ułożenie atomów w przestrzeni
---

##### **łupliwość** (definicja)
>zdolność kryształów do rozpadania się w sposób prawidłowy na części ograniczone płaskimi ścianami pod wpływem czynników mechanicznych
---

##### **przełam** (definicja)
>zdolność minerału do dzielenia się wzdłuż powierzchni nierównych, przypadkowych, niezwiązanych z wewnętrzną strukturą kryształu
---

##### **minerał magmowy** (definicja)
>minerał powstały w procesie krystalizacji magmy (np. krzemiany, glinokrzemiany)
---

##### **minerał pneumatolityczny**/**minerał hydrotermalny** (definicja)
>minerał powstały z przemiany pary, gorących roztworów wydzielających się z magmy (np. geody kwarcowe, minerały pegmatytów)
---

##### **minerał wulkaniczno-ekshalacyjny** (definicja)
>minerał powstały z par, gazów wulkanicznych
---

##### **minerał osadowy** (definicja)
>minerał powstały ze składników wód śródlądowych lub wód morskich, m.in. w wyniku procesów sedymentacji lub ewaporacji (np. kalcyt, gips, halit)
---

##### **minerał wtórny** (definicja)
>minerał powstający z minerałów pierwotnych w wyniku ich przemian fizycznych lub chemicznych w ramach procesów wietrzenia, diagenezy, metamorfizmu zachodzących pod wpływem działania wysokich temperatur lub ciśnienia
---

##### **skała** (definicja)
>naturalny zespół minerałów lub rzadziej bezpostaciowych składników nieorganicznych lub organicznych powstały w wyniku działania określonych procesów geologicznych lub kosmicznych i stanowiący zwykle możliwą geologicznie do wyodrębnienie jednostkę strukturalną
---

##### **skała magmowa** (definicja)
>skała powstała w skutek zastygania stopu magmowego w głębi skorupy ziemskiej lub na powierzchni Ziemi (np. krzemiany, glinokrzemiany)
---

##### **magma** (definicja)
>gorąca (700-900°C) oraz stopiona masa krzemianów i glinokrzemianów z domieszkami tlenków, siarczków z duża ilością wody i gazów
---

##### **skała osadowa** (definicja)
>skała powstała w skutek nagromadzenia się elementów mineralnych lub organicznych w postaci osadu na powierzchni skorupy ziemskiej
---

##### **warstwowanie** (definicja)
>występowanie warstw w skale osadowej
---

##### **diageneza** (definicja I)
>zespół procesów prowadzących do chemicznych, fizycznych, mineralnych zmian w osadzie po jego złożeniu
---

##### **diageneza** (definicja II)
>procesy tworzenia się skały zwięzłej ze skały luźnej
---

##### **skała metamorficzna** (definicja)
>skała powstała w skutek przeobrażania (metamorfozy) skały magmowej, skały osadowej lub skały metamorficznej pod wpływem czynników działających w głębi skorupy ziemskiej
---

##### **skała krystaliczna** (definicja)
>skała magmowa lub skała metamorficzna
---

##### **skała monomineralna** (definicja)
>skała składająca się z jednego minerału
---

##### **skała polimineralna** (definicja)
>skała składająca się z wielu minerałów
---

##### **wietrzenie** (definicja)
>reakcja minerału budującego litosferę na warunki środowiskowe istniejące na powierzchni Ziemi na styku atmosfery, hydrosfery i biosfery
---

##### **geomorfologia** (definicja)
>nauka o formach powierzchni Ziemi i procesach je kształtujących
---

##### **procesy geomorfologiczne** (definicja)
>procesy fizyczne lub chemiczne, które przyczyniają się do powstawania form terenu lub zespołu form terenu
---

##### **ruchy masowe** (definicja)
>procesy przemieszczania się mas zwietrzelinowych lub skalnych na stoku, które wywołane są grawitacją
---

##### **spłukiwanie** (definicja)
>procesy przemieszczania się mas zwietrzelinowych lub skalnych na stoku, które wywołane są wodą spływającą po stoku
---

##### **procesy stokowe** (definicja)
>procesy przemieszczania się mas zwietrzelinowych lub skalnych na stoku, które wywołane są grawitacją lub wodą spływającą po stoku
---

##### **stok** (definicja)
>nachylona powierzchnia
---

##### **kohezja**/**spójność międzycząsteczkowa** (definicja)
>wzajemne przyciąganie się cząsteczek skał
---

##### **tarcie wewnętrzne** (definicja)
>opór stawiany przez przesuwające się względem siebie cząsteczki
---

##### **korazja**/**abrazja** (definicja) (?)
>mechaniczne pogłębianie dna koryta rzeki w skutek uderzenia lub szorowania materiałem rumowiskowym, gdy obciążenie jest mniejsze od nośności rzeki
---

##### **eworsja** (definicja)
>pogłębianie odcinków dna koryta rzeki o mniejszej odporności na skutek ruchu wirowego wody przy udziale materiału rumowiskowego
---

##### **korozja** (definicja)
>pogłębianie dna koryta rzeki przy wykorzystaniu wietrzeni chemicznego
---

##### **erozja boczna** (definicja)
>rozmywanie lub podcinanie brzegów koryta rzeki przez płynącą wodę
---

---
---
---
---
---
