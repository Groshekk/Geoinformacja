---
przedmiot: Geografia fizyczna
date_zajec:
rodzaj_zajec: ćwiczenia
prowadzacy: Renata Paluszkiewicz

date: 31.08.2023
type: notatki
tag: notatki, geoinformacja, studia, Irok
---

# Geografia fizyczna; ćwiczenia
**ĆWICZENIA**
- tematy i szczegółowe zagadnienia
- notatki

---
# Tematy i szczegółowe zagadnienia
1. **Atmosfera, bilans energetyczny Ziemi**
	- budowa pionowa atmosfery, właściwości fizyczne, skład chemiczny
	- formy przenoszenia energii (promieniowanie, przewodzenie, konwekcja)
	- natura promieniowania - prawa promieniowania, promieniowanie krótkofalowe i długofalowe
	- przemiany energii promienistej w atmosferze
	- bilans promieniowania
	- efekt cieplarniany - mechanizm zjawiska
	- gazy cieplarniane, zawartość CO2, CH4 w atmosferze, jakie procesy wpływają na zawartość tych gazów w atmosferze, główne zbiorniki węgla na Ziemi (atmosfera, biosfera, osady, ocean), obieg węgla w przyrodzie
>			P. A. Allen, 2000, "Procesy kształtujące powierzchnie Ziemi", Warszawa: PWN, 17-20.
>			Kożuchowski, 2009, "Meteorologia i klimatologia", 10-27, 36-50.
>			J. Weiner, 1999, "Życie i ewolucja biosfery", 145-160.
2. **Przepływ ciepła na Ziemi - cyrkulacja atmosfery i oceanów**
	- ogólna cyrkulacja atmosfery, cyrkulacja monsunowa
	- cyrkulacja oceaniczna (prądy morskie, cyrkulacja termohalinowa, upwelling)
	- model oddziaływań: atmosfera-ocean  
	- pływy
>			Kożuchowski, 2009, "Meteorologia i klimatologia", 170-175, 197-204.
>			P. A. Allen, 2000, "Procesy kształtujące powierzchnie Ziemi", Warszawa: PWN, 29-37.
>			E. Bajkiewicz-Grabowska, Z. Mikulski, "Hydrologia ogólna", 266-278.
3. **Globalny obieg wody**  
	- obieg wody w przyrodzie
	- pojęcia: zlewnia, dorzecze
	- opady atmosferyczne (czynniki wpływające na wielkość opadów, pomiar opadów, czasowy rozkład opadów, natężenie i wydajność opadów
	- parowanie terenowe (transpiracja, ewapotranspiracja, parowanie potencjalne, rzeczywiste)
	- odpływ podziemny (infiltracja), spływ powierzchniowy
	- odpływ rzeczny (stany wody, miary odpływu)
	- hydrogram odpływu
	- wezbrania i niżówki, ustroje wodne rzek
>			E. Bajkiewicz-Grabowska, Z. Mikulski, "Hydrologia ogólna", 114-128, 138-157.
4. **Klimaty kuli ziemskiej**
	- strefowe i astrefowe czynniki klimatu
	- wiatry lokalne jako odbicie wpływu geograficznych czynników klimatu
	- podział kuli ziemskiej na strefy klimatyczne wg Okołowicza
	- człowiek a klimat (klimat obszarów zurbanizowanych, czy warunki klimatyczne wpływają na rozmieszczenie ludności na świecie?)
>			Z. Kaczorowska, 1977, "Pogoda i klimat", Warszawa: WSziP.
>			J. G. Lockwood, 1984, "Procesy klimatotwórcze", Warszawa: PWN.
>			W. Okołowicz, 1969, "Klimatologia ogólna", Warszawa: PWN.
5. **Zjawiska wulkaniczne i trzęsienia Ziemi**
	- warunki geologiczne i tektoniczne skorupy kontynentalnej i oceanicznej
	- ruchy skorupy ziemskiej
	- procesy orogeniczne i epejrogeniczne
	- procesy endogeniczne (zjawiska plutoniczne i wulkaniczne, rozmieszczenie wulkanów na kuli ziemskiej, typy erupcji wulkanicznych, budowa wulkanu )
	- trzęsienia ziemi, występowanie trzęsień ziemi na kuli ziemskiej, pomiary trzęsień ziemi, próby  przewidywania
	- budowa wnętrza Ziemi
	- typy skał
>			M. Książkiewicz, 1972, "Geologia dynamiczna", Warszawa: WG.
>			M. Klimaszewski, 1978, "Geomorfologia", Warszawa: PWN.
6. **Kriosfera**
	- lodowce, ich powstanie, występowanie i tendencje zmian
	- przebieg granicy wieloletniego śniegu w różnych strefach klimatycznych
	- warunki konieczne do powstania lodowców
	- typy i rozmieszczenie lodowców na kuli ziemskiej
	- elementy morfologiczne lodowca
	- formy pochodzenia polodowcowego
	- peryglacjał
>			A. Jahn, 1971, "Lód i zlodowacenia", Biblioteka Problemów, Warszawa: PWN.
>			J. Jania, 1988, "Zrozumieć lodowce", Katowice: Śląsk.
>			J. Jania, 1993, "Glacjologia", Warszaw: PWN.
>			J. Marcinek, 1991, "Lodowce kuli ziemskiej", Warszawa: PWN.
7. **Rzeźbotwórcza działalność sił zewnętrznych - wybrzeża morskie**
	- dynamika wód morskich w strefie wybrzeży
		- rola prądów przybrzeżnych w transporcie materiału
	- typy wybrzeży morskich wg Klimaszewskiego
		- przykłady ze świata
	- procesy kształtujące wybrzeża morskie (procesy niszczące i budujące)
	- formy brzegowe (formy erozyjne, formy akumulacyjne)
		- charakterystyka procesów i form kształtujących wybrzeża klifowe wyspy Wolin (wg sygnatury kartowania morfologicznego polskiego wybrzeża klifowego)
>			M. Klimaszewski, 1978, "Geomorfologia". Warszawa: PWN.
>			P. A. Allen, 2000, "Procesy kształtujące powierzchnię Ziemi", Warszawa: PWN.
>			A. Kostrzewski, Z. Zwoliński, 1994, "Bałtyckie wybrzeże klifowe wyspy Wolin - stan aktualny, tendencje rozwoju", "Klify",  t. 1, WPN, 81-99.
8. **Rzeźbotwórcza działalność sił zewnętrznych - procesy eoliczne**
	- erozyjna działalność wiatru
	- transport eoliczny
	- akumulacyjna działalność wiatru
	- typy pustyń
>			M. Klimaszewski, 1978: "Geomorfologia", Warszawa: PWN.
>			P. A. Allen, 2000, "Procesy kształtujące powierzchnie Ziemi", Warszawa: PWN.
9. **Rzeźbotwórcza działalność sił zewnętrznych - procesy wietrzenia skał**
	- odporność skał na wietrzenie i jej uwarunkowania
	- typy wietrzenia skał (wietrzenie mechaniczne, wietrzenie chemiczne, wietrzenie biologiczne)
	- główne strefy wietrzeniowe na świecie
	- formy wietrzeniowe, pokrywa zwietrzelinowa
>			M. Klimaszewski, 1978: "Geomorfologia", Warszawa: PWN.
>			P. A. Allen, 2000, "Procesy kształtujące powierzchnie Ziemi", Warszawa: PWN.
10. **Rzeźbotwórcza działalność sił zewnętrznych - działalność czynników denudacyjnych**
	- procesy denudacyjne
	- ruchy masowe - podział, uwarunkowania, charakterystyka
	- erozja wodna w obrębie stoku
	- teorie rozwoju stoku (spływ powierzchniowy, spłukiwanie, erozja wąwozowa)
>			M. Klimaszewski, 1978: "Geomorfologia", Warszawa: PWN.
>			P. Migoń, 2006, "Geomorfologia", Warszawa: PWN.
>			P. A. Allen, 2000, "Procesy kształtujące powierzchnie Ziemi", Warszawa: PWN.
>			C. Embleton, J. Thornes, 1985, "Geomorfologia dynamiczna", Warszawa: PWN.
11. **Geografia biosfery**
	- procesy glebotwórcze i pokrywy glebowe
	- przyczyny przestrzennego rozmieszczenia roślin na Ziemi (przyczyny biogenetyczne, czynniki siedliskowe, przyczyny biotyczne)
	- roślinność Ziemi (roślinność strefowa - zonalna, roślinność bezstrefowa - azonalna)
	- wpływ człowieka na szatę roślinną Ziemi (rośliny użytkowe, rośliny synantropijne)
>			Z. Podbielkowski, 1995, "Fitogeografia części świata", t. I-II, Warszawa: PWN.
>			Z. Podbielkowski, 1982, "Roślinność kuli ziemskiej", Warszawa: WSiP.
>			Z. Podbielkowski, 1991, "Geografia roślin", Warszawa: WSiP.
>			Z. Podbielkowski, 1992, "Rośliny użytkowe", Warszawa: WSiP.
12. **Antroposfera, interakcja człowiek-środowisko**
	- zmiany wywołane wydobywaniem surowców mineralnych
	- rekultywacja terenów zniszczonych na skutek działalności górniczej
	- zmiany spowodowane wykorzystaniem paliw kopalnych: globalne ocieplenie, przewidywane skutki globalnego ocieplenia)
	- wpływ rolnictwa na środowisko: zmiany krajobrazu (utrata siedlisk i bioróżnorodności), degradacja erozja i ochrona gleb, chemiczne środki ochrony plonów
	- procesy eutrofizacji jezior
	- definicja jeziora, genetyczne typy jezior
	- ustrój termiczny jezior - stratyfikacja termiczna jezior w klimacie umiarkowanym (stratyfikacja normalna -letnia, odwrócona - zimowa, warstwy termiczne w jeziorze - epilimnion, metalimnion, hipolimnion)
	- rola fosforu w procesie eutrofizacji jezior
	- typy troficzne jezior (jezioro oligotroficzne, eutroficzne, dystroficzne), różnice pomiędzy wymienionymi typami w zakresie: zawartości substancji pokarmowych (fosforu), zawartości tlenu
>			J. Weiner, 1999, "Życie i ewolucja biosfery", 173-175, 206-219.
>			E. Bajkiewicz-Grabowska, Z. Mikulski, "Hydrologia ogólna", 71-76, 165-169, 176-179, 187-191.
>			Antoinette Mannion, 2001, "Zmiany środowiska Ziemi. Historia środowiska przyrodniczego i kulturowego", Warszawa: Wydawnictwo Naukowe PWN.
>			P. A. Allen, 2000, "Procesy kształtujące powierzchnię Ziemi", Warszawa: PWN.
---
# Notatki
## Atmosfera, bilans energetyczny Ziemi
- [prawo Stefana-Boltzmanna](https://pl.wikipedia.org/wiki/Prawo_Stefana-Boltzmanna)
- [prawo Wiena](https://pl.wikipedia.org/wiki/Prawo_Wiena)
---
###### skład chemiczny atmosfery
| Udział | Pierwiastek |
| ------ |:-----------:|
| 78%    |    **N**    |
| 21%    |    **O**    |
| 1%     |   **Ar**    |

---
## Przepływ ciepła na Ziemi - cyrkulacja atmosfery i oceanów
#### komórki konwekcyjne
- komórka Hadleya
	- równik (**N**) ← zwrotnik (**W**)
- komórka Ferrela
	- zwrotnik (**W**) → krąg polarny (**N**)
- komórka polarna
	- krąg polarny (**N**) ← biegun (**W**)
---
>**N** ←*wiatr*← **W** - wiatr z wyżu do niżu
---
- 510 100 900 km2 - powierzchnia Ziemi
---
