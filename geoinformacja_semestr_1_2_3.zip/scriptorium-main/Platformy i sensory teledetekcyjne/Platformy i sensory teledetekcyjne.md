---
przedmiot: Platformy i sensory teledetekcyjne
date_zajec:
rodzaj_zajec:
prowadzacy: Jan Piekarczyk, Jakub Ceglarek
date: 27.11.2023
type: notatki
tags: notatki, geoinformacja, studia, IIrok
---

# Notatki
1. Satelity
	- tendencje w teledetekcji
	- satelity
2. Pułap lotniczy
3. Termia. Radar. LiDAR
	- teledetekcja termalna
	- teledetekcja radarowa
	- teledetekcja lidarowa
4. Pułap naziemny
	- informacje ogólne
	- czujniki wielospektralne i hiperspektralne
	- oprzyrządowanie
---
---
---
---
---
# Definicje z notatek
##### **dynamika matrycy** (dynamika)
>miara zdolności do jednoczesnej rejestracji obszarów jasnych i głębokich cieni
---

##### ***blooming*** (dynamika)
>jasność piksela przekracza poziom saturacji i oddziałuje na sąsiednie piksele
---

##### **pogoda fotolotnicza** (definicja)
> zespół zjawisk meteorologicznych umożliwiających wykonanie zdjęć lotniczych zgodnie z ich przeznaczeniem
---

##### **mgiełka atmosferyczna** (definicja)
>rozproszenie krótkofalowego promieniowania (ultrafioletowego prawie *100%*) spotęgowane przez obecność aerozoli
---

##### **nalot** (definicja)
>czynności związane z wykonywaniem zdjęć lotniczych
---

##### **szereg** (definicja)
>zestaw zdjęć wykonywanych wzdłuż jednej linii przelotu
---

##### **blok**/**zespół zdjęć lotniczych** (definicja)
>szeregi pokrywających się zdjęć lotniczych
---

##### **podłużna baza fotografowania**
>odległość pomiędzy środkami zdjęć (miejscami ekspozycji/naświetlania/wyzwolenia migawki) w szeregu
---

##### **projektowanie nalotów**
>zaplanowanie trasy przelotu po liniach szeregów lub ustalonej pozycji (*X, Y*/*X, Y, Z*) samych środków rzutu poszczególnych zdjęć 
---

##### **okluzja**
>zjawisko zakrywania obiektów znajdujących się dalej od kamery poprzez obiekty znajdujące się bliżej
---

##### **emisyjność** (definicja)
>stosunek energii wypromieniowanej z powierzchni materiału do energii wypromieniowanej z doskonałego emitera (ciało doskonale czarne) przy tej samej temperaturze, długości fali, warunkach obserwacji
---

##### **radar** (***Ra**dio **D**etection **a**nd **R**anging*) (definicja)
>aktywny system teledetekcyjny wysyłający promieniowanie elektromagnetyczne w zakresie mikrofalowym i rejestrującym powracającą wiązkę (echo radarowe) po jej odbiciu od obiektów znajdujących się na drodze wysyłanych fal
---

##### **skaner laserowy** (definicja)
>system zadanego pozyskiwania informacji składający się z emitera światła spójnego (skoncentrowana wiązka promieni) oraz odbiornika rejestrującego wiązkę zwrotną światła odbitego, na podstawie której można określić odległość od obiektu
---

##### **światło spójne**/**światło koherentne** (definicja I - znaczenie szersze)
>światło zdolne do interferencji
---

##### **światło spójne**/**światło koherentne** (definicja II - znaczenie węższe)
>światło składające się z fotonów zgodnych w fazie
---

##### **spektroskopia** (definicja)
>nauka o powstawaniu i interpretacji widm, uzyskanych w wyniku oddziaływań wszelkich rodzajów promieniowania na materię, rozumianą jako zbiorowisko atomów i cząsteczek
---

##### **spektrometria** (definicja)
>dziedzina zajmująca się rejestracją i pomiarami efektów wytwarzania bądź oddziaływania promieniowania elektromagnetycznego z badaną materią
---

##### **widmo spektroskopowe** (definicja)
>dwuwymiarowa zależność pomiędzy dwoma miarami, np. natężeniem promieniowania i długością fali elektromagnetycznej
---

##### **współczynnik odbicia** (definicja)
>stosunek natężenia fali odbitej do natężenia fali padającej
---

##### **radiometr** (definicja)
>instrument mierzący natężenie promieniowania elektromagnetycznego w pewnym paśmie długości fal
---

##### **spektometr** (definicja)
>urządzenie rozdzielające rejestrowane promieniowanie **EM** na pasma, w których mierzona jest jego intensywność
---

##### **spektroradiometr** (definicja)
>radiometr mogący mierzyć intensywność promieniowania w wielu pasmach długości fali (wielospektralne, hiperspektralne)
---

##### **spektrofotometr** (definicja)
>urządzenie mierzące ilość odbitego promienienia z zakresu optycznego lub widzialnego
---

##### **spektrograf** (definicja)
>przyrząd do otrzymywania i trwałej rejestracji widma
---

##### **monochromator** (definicja)
>przyrządy optyczny rozszczepiający światło w celu otrzymania jedynie niewielkiego fragmentu z jego widma
---

##### **dyfrakcja**/**ugięcie fali** (definicja)
>zmiana kierunku rozchodzenia się fali na krawędziach przeszkód oraz w ich pobliżu
---

##### **galwanometr** (definicja)
>czuły miernik magnetoelektryczny służący do mierzenie niewielkich wartości natężenie prądu elektrycznego (nawet do milionowych części ampera)
---

##### **kolimator** (definicja)
>przyrząd przetwarzający padające światło lub strumień cząstek w równoległą wiązkę (wiązka skolimowana)
---

##### **szerokość pasma**/**szerokość kanału** (definicja)
>szerokość zakresu odczytana dla 50% intensywności sygnału (szerokość pojedynczego kanału spektrometru)
---

##### **stosunek sygnału do szumu** (*signal-to-noise ratio*, ***S/N***) (definicja)
>wartość mocy sygnały użytecznego w zadanym paśmie do mocy szumów w tym samym paśmie
---
---
---
---
---
---
