---
przedmiot: Wstęp do geoinformacji
date_zajec:
rodzaj_zajec: wykład, laboratorium
prowadzacy: Zbigniew Zwoliński, Patrycja Przewoźna

date: 01.09.2023
type: notatki
tags: notatki, geoinformacja, studia, Irok
---

# Egzamin
## Zadania z egzaminu; 21.12.2022
1. definicja *GIS* wg D. Maguire 2011
2. 5 kamieni milowych w rozwoju GIS
3. zalety modelu rastrowego
4. charakterystyka wielkich danych
---
---
## Zaliczenie laboratoriów; 01.02.2023
##### Dysponujesz następującymi danymi przestrzennymi:
 - *dzikie2014.gml* - warstwa opracowana przez studentów koła naukowego WNGiG w oparciu o dane nieprzestrzenne uzyskane od Urzędu Miasta Poznań;
  wskazuje nielegalne składowiska odpadów (tzw. “dzikie wysypiska”) zgłoszone przez mieszkańców (i usunięte przez władze miasta) w roku 2014;
  zawiera informację o kodzie (*fid*), numer porządkowi (*id*) oraz informację o masie usuniętych dzikich wysypisk podanej w Mg, czyli tonach (Odp__Mg_)
- *Poznan.gpkg* (baza danych zawiera tylko jedną warstwę - osiedla, czyli podstawowe jednostki administracyjne miasta Poznań),
- *drogi.shp* - warstwa opracowana przez Zarząd Geodezji i Katastru Miejskiego GEOPOZ, przedstawiająca sieć dróg miasta,
- *Natura2000.gml* - warstwa wskazująca na Specjalne Obszary Ochrony Natura2000, znajdujące się w obrębie miasta,
- *DEM.tif* - model wysokościowy terenu.
---
#### CZ. I (maksymalna ocena to 4,5)
Twoim zadaniem jest przygotować opracowanie kartograficzne dla Urzędu Miasta Poznań, pokazujące lokalizację dzikich wysypisk zgłoszonych do urzędu w roku 2014.
Opracowanie kartograficzne ma być przygotowane do druku – arkusz o wymiarach A4 (pion) i powinno się na nim znaleźć:
- mapa prezentująca wszystkie dzikie wysypiska, jakie znajdują się na terenie miasta Poznań, na tle do granic administracyjnych osiedli, która:
	- zawiera informacje odnośnie osiedli, na których odnotowano problem pojawienia się dzikich wysypisk (ich nazwy muszą być widoczne na mapie),
	- jako dane kontekstowe, pozwalające sprawdzić, czy bliskość dróg może mieć znaczenie dla problemu, wskazuje również na sieć dróg miasta,
	- dodatkowo prezentuje również lokalizację Punktów Selektywnego Zbierania Odpadów Komunalnych w Poznaniu (Gratowiska) - w Poznaniu mamy dwa takie punkty (ich lokalizacja ma pokazać, na ile oddalenie od punktów zbiórki może sprzyjać pojawianiu się problemu dzikich wysypisk).
- mapa, pozwalająca odróżnić małe nielegalne wysypiska od dużych: należy wyraźnie wskazać, z których “dzikich wysypisk” zebrano 1Mg (1 tonę) odpadów lub więcej, a z których zebrano mniej odpadów.
- mapa prezentująca przybliżenie na “dzikie wysypisko”, z którego zebrano najwięcej odpadów.
Opracowanie powinno zawierać datę jego sporządzenia (ale nie powinno zawierać informacji o tym, kto je przygotował), oraz wszystkie dodatkowe informacje pozwalające na prawidłową interpretację obiektów prezentowanych na mapie, oraz ich wielkości.
---
#### CZ. II (na 5)
Opracowana przez Ciebie wizualizacji dodatkowo przy nielegalnym wysypisku odpadów, z którego zebrano największą masę śmieci, informuje na jakiej wysokości się ono znajduje.
Opracowanie kartograficzne w formacie *.png* (dpi 120) należy wgrać na platformę *MS Teams* do godz. 16:25. W przypadku przekroczenia tego czasu, ocena końcowa zostanie obniżona.
Po godz. 16:30 nie będzie już możliwości oddania pracy zaliczeniowej. 

---
#### Kryteria oceny części praktycznej "Wstępu do geoinformacji"
##### Zawartość opracowania:
- **DOSKONALE** (5 pkt) - Wykonano całkowicie poprawnie wszystkie części zaliczenie (cz. I i cz. II).
- **DOBRZE** (4 pkt) - Opracowanie zawiera wszystkie 3 mapy, wskazane w cz. I, choć nie wszystko wykonano zgodnie z poleceniem.
- **DOSTATECZNIE** (3 pkt) - Opracowanie zawiera poprawnie opracowaną minimum jedną ze trzech map wskazanych do wykonania cz. I.
- **ŹLE** ( pkt) - Zadanie zrealizowane nie zgodnie z poleceniem lub w zbyt małym stopniu.
##### Estetyka opracowania:
- **DOSKONALE** (5 pkt) - Opracowanie zawiera wszystkie elementy pozwalające na prawidłową interpretację obiektów prezentowanych na mapie, oraz ich wielkość, a do tego przedstawia wysokie walory estetyczne.
- **DOBRZE** (4 pkt) - Opracowanie zawiera wszystkie elementy pozwalające na prawidłową interpretację obiektów prezentowanych na mapie, oraz ich wielkość.
- **DOSTATECZNIE** (3 pkt) - Opracowanie zawiera dodatkowe elementy opisujące treść mapy, ale są one niekompletne lub w niejednoznaczny sposób opisują obiekty prezentowane na mapach i ich wielkość.
- **ŹLE** ( pkt) - Nie zadbano w ogóle o czytelność załączonego opracowania kartograficznego.
---
---
---
# Notatki
1. Wprowadzenie
    - definicje GIS
    - funkcje GIS/geoinformacji
    - GIS a geoinformacja a geoinformatyka
    - podział systemów informacji przestrzennej
2. Definicje GIS
3. Interdyscyplinarność geoinformacji. Analizy przestrzenne
4. Rozwój GIS
5. GIS a geografia
6. Encje
7. Modele danych
    - model rastrowy
    - model wektorowy
8. Przyszłość GIS
9. GIS w Polsce
    - ustawodawstwo geoinformatyczne w Polsce
    - państwowe geoportale w Polsce
---
---
---
---
---
# Definicje z notatek

##### **system** (definicja)
>zbiór niezależnych i oddziałujących wzajemnie na siebie obiektów/bytów tworzących zintegrowaną całość
---

##### **informacja** (definicja I)
>norma ściśle powiązana z koncepcjami rozumienia, kształcenia, porozumienia, odwzorowań, bodźców mentalnych
---

##### **informacja** (definicja II)
>dane mogące reprezentować zbiór faktów, cech, liczb, ...
---

##### **geograficzny** (definicja)
>położony w przestrzeni/geoprzestrzeni
---

##### **GIS**/**SIG** (**T. Polak 2009**) (definicja)
>*system uniwersalny, który usiłuje objąć swoim teoretycznym zasięgiem także te osoby, które do nich nie należą z własnego wyboru*
---

##### **GIS** (**K. J. Duecker 1979**) (definicja)
>specjalny zestaw systemów informacji, w którym baza danych składa się z obserwacji o cechach, działalnościach i zdarzeniach rozlokowanych przestrzennie, które są określane w przestrzeni jako punkty, linie, obszary;
>GIS przetwarza dane o nich celem uzyskania informacji na stawianie pytania i analizy
---

##### **GIS** (**P. A. Burrough 1986**) (definicja) [WAŻNA]
>potężny zbiór narzędzi do zbierania, przechowywania, dowolnego odzyskiwania, przetwarzania i prezentacji danych przestrzennych świata rzeczywistego
---

##### **GIS** (**D. J. Cowen 1988**) (definicja)
>system dostarczania decyzji
---

##### **GIS** (**J. R. Carter 1989**) (definicja)
>instytucjonalna jednota oddająca strukturę organizacyjną, która scala technologię z bazą danych, ekspertyzą, poparciem ciągłości finansowej w ciągu czasu
---

##### **GIS** (**D. J. Maguire 1991**) (definicja) [WAŻNA]
>zintegrowany zestaw: sprzętu komputerowego, oprogramowania, danych, specjalistów; które to elementy działają w kontekście instytucjonalnym
---

##### **GIS** (**D. J. Maguire 1998**) (definicja)
>zintegrowany zestaw: sprzętu komputerowego, oprogramowania, danych, **metod badawczych**, specjalistów; które to elementy działają w kontekście instytucjonalnym
---

##### **GIS** (**D. J. Maguire 2011**) (definicja) [WAŻNA]
>zintegrowany **sieciowo** zestaw: sprzętu komputerowego, oprogramowania, danych, **metod badawczych**, specjalistów; które to elementy działają w kontekście instytucjonalnym
---

##### **geoinformacja** (definicja)
>nauka redefiniująca, rozwijająca dotychczas uznane i przyjęte koncepcje, teorie i poglądy nauk geograficznych w kategoriach informatycznych, dające nowe możliwości interpretacyjne
---

##### **geoinformacja jako model krytyczno-empiryczny** (**Z. Chojnicki 2009**) (definicja)
>rozszerzanie bazy empirycznej zasięgu badań poprze informatyzację
---

##### **geoinformatyka** (definicja)
>zestaw technologii informatycznych posługujących się danymi odniesionymi do geoprzestrzeni
---

##### **dane przestrzenne** (definicja)
>dane zawierające informacje o kształcie i lokalizacji bezwzględnej obiektów w układzie odniesienia oraz ich wzajemnym rozmieszczeniu (topologia)
---

##### **dane nieprzestrzenne** (definicja)
>dane opisujące cechy ilościowe i jakościowe obiektów geograficznych niezwiązanych z ich rozmieszczeniem w przestrzeni
---

##### **neogeografia**/**nowa geografia** (**T. Giętkowski**) (definicja)
>zasób wiedzy, umiejętności i narzędzi w pełni umożliwiającej powszechne i codzienne korzystanie z informacji przestrzennych poprzez wykorzystywanie współczesnych technologii jej przekazu
---

---
---
---
---
---
