---
przedmiot: Geografia społeczno-ekonomiczna i humanistyczna
date_zajec:
rodzaj_zajec: wykład, ćwiczenia
prowadzacy: Urszula Kaczmarek

date: 03.06.2023
type: notatki
tag: notatki, geoinformacja, studia, Irok, egzamin
---
# Notatki
1. **Wprowadzenie**
	- Geografia społeczno-ekonomiczna i humanistyczna
	- Geografia internetu
	- Krajobraz kulturowy
	- Nassim Taleb
2. **System państwowy. Geografia *gender***
	- Państwo
	- Rodzaje niesuwerennych państw i terytoriów
	- Geografia *gender*
3. ***Terra nulis***
	- Morza
	- Antarktyka
	- Arktyka
4. **Integracja**
	- Procesy integracji
	- Organizacja międzynarodowa
5. **Dezintegracja**
	- Zagrożenia państwowe
	- Terroryzm
	- Piractwo morskie
	- Zagrożenia cyberprzestrzeni
6. **Demografia**
	- Teorie ludnościowe
	- Rozmieszczenie ludności
	- Miary demograficzne
	- Dynamika demograficzna świata
	- Prokreacja
	- Demografia Polski
7. **Migracja - teoria**
	- Klasyfikacja migracji
	- *Migration Transition Model*
	- Ekonomiczne teorie migracji
	- Prawa migracji
	- Mechanizm migracji
8. **Migracja - historia**
	- Migracje do Nowego Świata (XVIII-XIX w.)
	- Migracje do Europy Zachodniej (II poł. XX w.)
	- Polska a migracja
	- Skutki migracji
	- Uchodźstwo
9. **Urbanizacja**
	- Procesy urbanizacji i jej aspekty badawcze
	- Kryteria miejskości i zurbanizowania
	- Dynamika urbanizacji na świecie
	- Hiperurbanizacji w krajach Trzeciego Świata
	- Fazy urbanizacji krajów rozwiniętych
	- Metropolizacja
	- Rewitalizacja miast
10. **Globalizacja**
	- Pojęcie globalizacji
	- Aspekty globalizacji
	- Przyczyny globalizacji
	- Zagraniczna ekspansja gospodarcza
 - **Ćwiczenia**
	- struktura demograficzna
	- struktura społeczna
	- urbanizacja
---
---
---
---
---
# Definicje z notatek

##### **przedmiot wykładu** (geografia społeczno-ekonomiczna i humanistyczna)
>zjawiska i procesy społeczno-gospodarcze, kulturowe w zróżnicowaniu przestrzennym
---

##### **podmiot wykładu** (geografia społeczno-ekonomiczna i humanistyczna)
>świat w ujęciu od lokalnego do globalnego
---

##### **geografia społeczno-ekonomiczna**
>dyscyplina zajmująca się zjawiskami i procesami ludnościowymi, osadniczymi, kulturowymi, politycznymi, gospodarczymi; w ujęciu przestrzennym i środowiskowym; w celu poznania organizacji (rozmieszczenie, działanie) i funkcjonowania systemu społeczno-gospodarczego
---

##### **system społeczno-gospodarczy**
>ludzie (układy społeczne) i ich wytwory (układy techniczno-kulturowe)
---

##### **geografia medyczna**
>subdyscyplina zajmująca się przestrzennym zróżnicowaniem zjawisk chorobowych, procesu dyfuzji chorób, geograficznych nierówności w poziomie zdrowia ludności, uwarunkowań zachorowalności
---

##### **humanistyczny model geografii**
>humanistyczne podejście w badaniach geograficznych uwzględniające subiektywne, aksjologiczne aspekty działalności człowieka i jego empatii
---

##### **geografia internetu**
>subdyscyplina geografii społeczno-ekonomicznej zajmująca się przestrzennym wymiarem działalności człowieka związanymi z funkcjonowaniem, korzystaniem i tworzeniem internetu, ich społecznych, ekonomicznych konsekwencjach oraz określaniem relacji między przestrzenią cyfrową a przestrzenią rzeczywistą
---

##### ***genre de vie*** ([Paul Vidal de la Blache](https://en.wikipedia.org/wiki/Paul_Vidal_de_La_Blache))
>sposób życia powiązany z relacjami społeczności ze środowiskiem 
---

##### [***milieu***](https://en.wikipedia.org/wiki/Social_environment) (I)
>środowisko społeczne
---

##### [***milieu***](https://en.wikipedia.org/wiki/Social_environment) (II)
>względnie trwały układ jednostek, grup/zbiorowości społecznych oddziałujących na człowieka
---

##### **krajobraz kulturowy** (I)
>kompleksowa całość geograficzna obejmująca elementy przyrodnicze i antropologiczne środowisko przetworzone przez człowieka w sposób fizyczny, materialny, symboliczny naznaczone śladami takiej działalności pochodzącymi z różnych okresów krajobraz naturalny przetworzony przez grupę kulturową
---

##### **krajobraz kulturowy** (II)
>rezultat odziaływania czynnika (kultura) na medium (krajobraz naturalny)
---

##### **krajobraz kulturowy** (fenomenologia)
>*żywy proces, który wyłania się z tego co materialne oraz rutynowo podejmowanych aktywności (zadań) człowieka i społeczności, przyczyniających się do transformacji krajobrazu*
---

##### **krajobraz kulturowy** (**T. Ingold**; fenomenologia)
>*proces, który nie jest zakończony i nigdy nie jest w pełni ukształtowany*
---

##### **krajobraz kulturowy** (**S. Daniels** & **D. Cosgrove**; ikonografia krajobrazu)
>sposób widzenia i wynik widzenia
---

##### **krajobraz kulturowy** (**J. Duncan** & **N. Duncan**; poststrukturalizm)
>tekst ustanawiany w dyskursie
---

##### **krajobraz kulturowy** (**N. Green**; "hermeneutyka")
>dialog
---

##### **siła**/**moc**/**potencjał państwa**
>suma kapitału ekonomicznego, wojska, ziem, zasobów ludzkich, kultury, siły dyplomatycznej
---

##### **płeć społeczno-kulturowa**/***gender***
>zespół cech i zachowań, ról płciowych, stereotypów przypisywanych kobietom i mężczyzną przez społeczeństwo i kulturę
---

##### **geografia *gender***
>dziedzina zajmująca się zróżnicowaniem przestrzennym różny aspektów tożsamości płciowej oraz ich społecznymi, kulturowymi, ekonomicznymi uwarunkowaniami
---

##### **organizacja międzynarodowa**
>organizacja zrzeszająca przynajmniej 3 podmioty utworzone dla realizacji wspólnego celu, który ma charakter międzynarodowy lub realizowany jest przez działalność międzynarodową
---

##### **terroryzm**
>metoda działania polegająca na przemocy wobec pojedynczych osób, aparatu władzy lub wobec przypadkowych członków społeczeństwa przez zamachy na urzędy, lokale publiczne, koszary. Celem tych aktów jest wymuszenie ustępstw na legalnych władzach, destabilizacja władzy przez zastraszenie...
---

##### **piractwo** (***Konwencji o morzu pełnym***, art. 15; Genewa, **29.04.1958**)
>*każdy bezprawny akt gwałtu, zatrzymania lub grabieży popełniony dla celów osobistych przez załogę prywatnego statku*
---

##### **cyberterroryzm** (I)
>politycznie motywowane atakowanie komputerów, systemów i sieci informatycznych w celu osiągniecia określonych korzyści
---

##### **cyberterroryzm** (II)
>dokonywanie aktów terroru polegających na celowym zakłóceniu interaktywnego, zorganizowanego obiegu informacji w cyberprzestrzeni, i których celem jest wyrządzenie szkody z pobudek politycznych lub ideologicznych, przy pomocy zdobyczy technologii informacyjnej
---

##### **cyberwojna** (**R. Clarke**)
>*działalność państw mającą na celu penetrację systemów i sieci komputerowych innych podmiotów międzynarodowych dla dokonania określonych zniszczeń lub zakłóceń*
---

##### **uchodźca** (***Konwencja dotycząca statusu uchodźców***, art. 2. 2); **29.07.1951**)
>osoba, która na skutek uzasadnionej **obawy przed prześladowaniem z powodu swojej rasy, religii, narodowości, przynależności do określonej grupy społecznej lub z powodu przekonań politycznych** przebywa poza granicami państwa, którego jest obywatelem, i nie może lub nie chce z powodu obaw korzystać z ochrony tego państwa, albo która nie ma żadnego obywatelstwa i znajdując się, na skutek podobnych zdarzeń, poza państwem swojego dawnego stałego zamieszkania nie może lub nie chce powodu tych obaw powrócić do tego państwa
---

##### **urbanizacja**
>proces rozwoju miejskich form osadniczych, ich liczby, zaludnienia, powierzchni, zabudowy, infrastruktury technicznej i społecznej, a także zmian ich struktury funkcjonalnej i przestrzennej oraz stylu życia ich mieszkańców
---

##### **ruralizacja**
>rozwój wiejskich form osadniczych
---

##### **semiurbanizacja**
>urbanizacja terenów wiejskich
---

##### **suburbanizacja**
>urbanizacja strefy podmiejskiej (przedmieść)
---

##### **dezurbanizacja**
>zanik cech i funkcji miejskich
---

##### **reurbanizacja**
>ponowna urbanizacja (odnowa / rewitalizacja miast)
---

##### **metropolizacja**
>proces koncentracji władzy, kapitału, centrów, zarządzania, nowoczesnej gospodarki, ośrodków medialnych i kulturalnych w największych wybranych miastach o randze światowej lub kontynentalnej prowadzące do ich zmian funkcjonalnych i przestrzennych i morfologicznych
---

##### **rewitalizacja**
>planowe zintegrowane działanie mające na celu zmianę struktury przestrzenno-funkcjonalnej zdegradowanych obszarów miasta...
---

##### **gentryfikacja**
>zmiana charakteru części miasta na obszar bardziej bogaty, zamieszkany przez bogatszych mieszkańców, o wyższym prestiżu
---

##### **globalizacja** (I)
>proces, w którym poprzez dynamiczny rozwój przepływu dóbr, usług, kapitału, technologii i informacji, produkcja i rynki na świecie są od siebie coraz bardziej zależne
---

##### **globalizacja** (II)
>historyczny proces wzrastającej integracji gospodarki w wymiarze światowym sterowany przez przedsiębiorstwa międzynarodowe, organizacje międzynarodowe i państwa narodowe
---

##### **globalizacja** (III)
>uznanie całego świata za jeden wielki rynek i przeniesienie punktu ciężkości w wymianie międzynarodowej z handlu zagranicznego na produkcję międzynarodową w przedsiębiorstwach międzynarodowych
---

##### **firma globalna**
>przedsiębiorstwo, które prowadzi za granicą kontrolowane przez siebie przedsięwzięcia i traktuje je na równi z operacjami krajowymi kierując się globalną strategią nakierowaną na zysk
---

---
---
---

##### **analfabetyzm** (UNESO)
>brak umiejętności czytania, pisania i wykonywania podstawowych działań matematycznych (dodawanie, odejmowanie, mnożenie, dzielenie) u osób powyżej 15 roku życia
---

##### **wtórny analfabetyzm funkcjonalny**
> brak umiejętności czytania tekstów ze zrozumieniem, wykonywania niezbyt trudnych obliczeń (obliczanie udziału procentowego, obliczanie wysokości podatku), stosowania technologii informatycznych
---

##### **cyfrowy analfabetyzm**
> brak umiejętności stosowania technologii informatycznych
---

##### **religia**
> system wierzeń i związanych z nimi praktyk określających związki między sferą boską a człowiekiem i społecznościami
---

##### **urbanizacja** (ujęcie **wąskie**)
> *wzrost miast i ludności miejskiej, wzrost udziału ludności miejskiej w stosunku do ogółu ludności*
---

##### **urbanizacja** (**Hope Tisdale**; ujęcie **wąskie**)
> *proces koncentracji ludności, który przebiega w dwojaki sposób. Polega, po pierwsze, na wzroście liczby punktów, w których następuje koncentracja, po drugie, na zwiększaniu się liczby ludności w tych punktach.*
---

##### **urbanizacja** (ujęcie **szerokie**)
> *proces społeczny i kulturowy wyrażający się w rozwoju miast, wzroście ich liczby, powiększaniu obszarów miejskich i udziału ludności miejskiej w całości zaludnienia*
---

---
---
---
---
---
