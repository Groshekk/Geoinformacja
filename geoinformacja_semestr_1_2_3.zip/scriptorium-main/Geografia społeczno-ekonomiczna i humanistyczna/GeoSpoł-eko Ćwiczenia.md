---
przedmiot: Geografia społeczno-ekonomiczna i humanistyczna
date_zajec:
rodzaj_zajec: ćwiczenia
prowadzacy: Urszula Kaczmarek

date: 20.06.2023
type: notatki
tag: notatki, geoinformacja, studia, Irok, egzamin
---

# Geografia społeczno-ekonomiczna i humanistyczna; ćwiczenia
**ĆWICZENIA**
	struktura demograficzna
	struktura społeczna
	urbanizacja


---
# Struktura demograficzna
#### ekonomiczne grupy wieku
- wiek przedprodukcyjny (*pre-working age*) - **0-17**
- wiek produkcyjny (*working age*) ♀**18-59**/♂**18-64**
	- wiek mobilny (*mobil age*) **18-44**
	- wiek niemobilny (*inmobil age*) ♀**45-59**/♂**45-64**
- wiek poprodukcyjny (*post working age*) ♀**60-**/♂**65-**
	- starość wczesna ♀**60-74**/♂**65-74**
	- starość późna **75-89**
	- starość długowieczna **90-**
---
#### współczynnik obciążenia demograficznego
- wskaźnik określający stosunek osób w wieku przedprodukcyjnym i poprodukcyjnym do liczby osób w wieku produkcyjnym [%]
- w Unii Europejskiej w **2019 r.** wynosił **54,9%** - na 1 osobę "utrzymywaną" przypadają ~2 osoby "utrzymujące"
---
# Struktura społeczna
## Wykształcenie
- poziom analfabetyzmu / poziom alfabetyzacji
- liczba studentów i osób z wyższym wykształceniem
- związane z poziomem rozwoju cywilizacyjnego państwa, potencjałem ludnościowym państwa (ilość, kwalifikacje siły roboczej)
#### analfabetyzm
##### analfabetyzm (**UNESO**)
>brak umiejętności czytania, pisania i wykonywania podstawowych działań matematycznych (dodawanie, odejmowanie, mnożenie, dzielenie) u osób powyżej 15 roku życia
---
##### wtórny analfabetyzm funkcjonalny (definicja)
> brak umiejętności czytania tekstów ze zrozumieniem, wykonywania niezbyt trudnych obliczeń (obliczanie udziału procentowego, obliczanie wysokości podatku), stosowania technologii informatycznych
---
##### cyfrowy analfabetyzm (definicja)
> brak umiejętności stosowania technologii informatycznych
---
## Rasy ludzkie
- rasy/odmiany ludzkie odnoszą się do odrębnych cech wyglądu zewnętrznego ludzi, które wykształciły się poprzez przystosowywanie się do różnych warunków klimatycznych (rysy twarzy, kolor skóry, wzrost, grupa krwi)
---
## Etniczność
- kraj monoetniczny
- kraj wieloetniczny
- mniejszość narodowa
- mniejszość etniczna
---
## Religia
- religia naturalna (kult płodności, kult przodków, kult sił natury)
- religia objawiona (prorok, święty tekst)
- religia narodowa (judaizm, sintoizm, hinduizm)
- religia neopogańska
- religia uniwersalna
---
##### religia (definicja)
> system wierzeń i związanych z nimi praktyk określających związki między sferą boską a człowiekiem i społecznościami
---
# Urbanizacja
- urbanizacja w ujęciu **szerokim** jest związana z:
	- industrializacja
	- modernizacja
	- zmiany kulturowe - tworzenie się miejskich stylów życia
---
##### urbanizacja (ujęcie **wąskie**)
> *wzrost miast i ludności miejskiej, wzrost udziału ludności miejskiej w stosunku do ogółu ludności*
---
##### urbanizacja (**Hope Tisdale**; ujęcie **wąskie**)
> *proces koncentracji ludności, który przebiega w dwojaki sposób. Polega, po pierwsze, na wzroście liczby punktów, w których następuje koncentracja, po drugie, na zwiększaniu się liczby ludności w tych punktach.*
---
##### urbanizacja (ujęcie **szerokie**)
> *proces społeczny i kulturowy wyrażający się w rozwoju miast, wzroście ich liczby, powiększaniu obszarów miejskich i udziału ludności miejskiej w całości zaludnienia*
---
#### aspekty urbanizacji (**szerokie** ujęcie)
- **aspekt demograficzny**
	- ruch ludności ze wsi do miast
	- koncentracja ludzi w miastach
	- wzrost udziału mieszkańców miast w populacji danego obszaru
- **aspekt przestrzenny**
	- zwiększanie się terytoriów miast
	- powiększanie się pojemności miast
	- powstawanie nowych miast
	- powstawanie nowych osiedli nierolniczych
	- przekształcanie środowisk mieszkalnych na wzór miejski
- **aspekt ekonomiczny**
	- wzrost liczby ludzi pracujących w zawodach nierolniczych
	- wzrost zróżnicowania zawodowego "ludności nierolniczej" w stosunku do "ludności rolniczej"
- **aspekt społeczny**
	- przyjmowanie przez ludzi przenoszących się ze wsi do miast miejskiego stylu życia
	- przenikanie miejskich wzorów ekonomicznych, wzorów społecznych, wzorów kulturowych na wieś
---
#### stadia urbanizacji (**L. van Klassen**, **L. van den Berg**)
1. **urbanizacja**
	- wzrost liczby ludności miejskiej
	- maksymalna koncentracja ludności miejskiej w centrum miasta i dzielnicach je otaczających
2. **suburbanizacja**
	- szybki rozwój przestrzenny miasta
	- spadek liczby ludności w centrum miasta
	- wzrost liczby ludności na obszarach podmiejskich
3. **dezurbanizacja**
	- dalszy spadek liczby ludności w centrum miasta prowadzący do spadku liczby ludności w całym mieście
	- wzrost liczby ludności na obszarach otaczających miasto, ale administracyjnie do niego nienależących
4. **reurbanizacja**
	- powolny wzrost liczby ludności do centrum miasta, często inspirowany celowymi działaniami władz dążącymi do jego ożywienia, odbudowy
---
