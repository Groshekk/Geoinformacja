---
przedmiot: Kartografia i topografia
date_zajec:
rodzaj_zajec: wykład
prowadzacy: Iwona Hildebrandt-Radke

date: 05.09.2023
type: notatki
tags: notatki, geoinformacja, studia, Irok
---

# Notatki
1. Wprowadzenie
    - mapa
    - definicje kartografii i topografii
    - historia kartografii
    - układy współrzędnych
2. KartoTopo Mapa
    - mapa
    - rodzaje map
3. Powierzchnia odniesienia. Odwzorowanie kartograficzne
    - geoida i elipsoida
    - systemy i układy odniesienia
    - odwzorowanie kartograficzne
    - rodzaje odwzorowań kartograficznych
4. Układy współrzędnych
5. Metody kartograficzne. Mapy Polski
    - mapa
    - metody kartograficzne
    - mapy topograficzne
    - mapy tematyczne
    - mapy numeryczne
6. Modele rzeczywistości geograficznej. Modele danych
    - modele danych
    - cyfrowe przetwarzanie mapy analogowej
7. Pomiary terenowe
    - przyrządy pomiarowe
    - metody pomiarów terenowych
8. GPS - ***brak notatek***
9. Systemy nawigacji satelitarnej - ***brak notatek***
    - Galileo
    - GLONASS
    - Compass/BeiDou
    - IRNSS
    - systemy wspomagania satelitarnego
    - odbiorniki GPS
10. NMT
    - definicje NMT
    - cechy NMT
11. Geowizualizacja - ***brak notatek***
---
---
---
---
---
# Definicje z notatek

##### **mapa** (definicja)
>aparat wielostronnych pośrednich badań rzeczywistości
---

##### **kartografia** (definicja I)
>nauka zajmująca się sposobami przedstawiania i badania przestrzennego rozmieszczenia oraz właściwości geograficznych, społecznych i gospodarczych
---

##### **kartografia** (definicja II)
>dziedzina nauki zajmująca się zasadami tworzenia, opracowania, edytowania map i możliwości korzystania z ich treści
---

##### **kartografia** (definicja III)
>nauka, sztuka, technologia sporządzania map; ich badanie jako dokumentu nauki, działa sztuki
---

##### **kartografia** (definicja IV)
>nauka metodyczna o modelowaniu, obrazowaniu czasoprzestrzennych struktur informacyjnych w postaci map opisujących wielowymiarową rzeczywistość
---

##### **kartografia** (definicja V)
>dyscyplina zajmująca się graficznym, komunikacyjnym, wizualno-myślowym, technologicznym opracowaniem informacji przestrzennej na podstawie map, innych reprezentacji kartograficznych
---

##### **topografia** (definicja I)
>dział zajmujący się wykorzystywaniem pomiarów obiektów na powierzchni Ziemi i rzeźby terenu w celu sporządzania map topograficznych
---

##### **topografia** (definicja II)
>zespół cech zewnętrznych obejmujących formy rzeźby terenu wraz z elementami krajobrazu naturalnego, antropologicznego, kulturowego
---

##### **topografia** (definicja III)
>dział łączący kartografię i geodezję
---

##### **szerokość geograficzna** (***φ***) (definicja)
>kąt między punktem a równikiem
---

##### **długość geograficzna** (***λ***) (definicja)
>kąt między punktem a południkiem 0°
---

##### **wysokość** (definicja)
>wysokość mierzona względem sfery, elipsoidy obrotowej
---

##### **szerokość geograficzna geodezyjna** (***B***) (definicja)
>kąt zawarty między normalną do elipsoidy przechodząca prze punkt a płaszczyzną równika
---

##### **długość geograficzna geodezyjna** (***L***) (definicja)
>kąt dwuścienny między południkiem 0° a południkiem, na którym leży punkt
---

##### **wysokość geograficzna geodezyjna**/**wysokość elipsoidalna** (***h***) (definicja)
>odcinek między punktem a punktem przebicia elipsoidy normalną
---

##### **wysokość bezwzględna** (definicja)
>wyniesienie nad powierzchnię geoidy lub poziom morza, mierzone wzdłuż linii pionowych przechodzących przez punkt
---

##### **wysokość względna** (definicja)
>wysokość nad dowolnie wysoko przyjętą powierzchnią poziomą obraną tak, by nie otrzymać wartości ujemnych (poziom względny lub lokalny poziom odniesienia)
---

##### **wysokość ortometryczna** (definicja)
>odległość od powierzchni Ziemi do geoidy mierzona wzdłuż linii w rzeczywistym polu siły ciężkości
---

##### **mapa anamorficzna** (definicja)
>przedstawienie, na którym powierzchnie obszarów są proporcjonalne do wielkości statystycznych
---

##### **globus** (definicja)
>trójwymiarowy model Ziemi przedstawiający ją na kuli zamiast na płaszczyźnie (uniknięcie odkształceń odwzorowawczych)
---

##### **blokdiagram** (definicja)
>obraz fragmentu Ziemi przy nachylonym kącie widzenia uzupełniony profilami lub przekrojami powierzchni, który prezentuje poglądowo jego cechy (np. rzeźbę terenu)
---

##### **schemat** (definicja)
>przedstawienie, na którym wiernie ukazane są niektóre cechy przestrzenne
---

##### **mapa analogowa** (definicja I)
>zmniejszony, uogólniony, matematycznie odwzorowany na płaszczyźnie obraz określonego obszaru Ziemi jednoznacznie orientujący w położeniu przestrzennym obiekty występujące na obszarze
---

##### **mapa analogowa** (definicja II)
>model rzeczywistości geograficznej rejestrujący stan rzeczywistości zgodny z datą pozyskania danych
---

##### **mapa komputerowa**/**mapa numeryczna**/**mapa cyfrowa** (definicja I)
>model części rzeczywistości geograficznej rejestrujący obraz jej faktów z możliwością aktualizacji danych w trybie *on-line*
---

##### **mapa komputerowa**/**mapa numeryczna**/**mapa cyfrowa** (definicja II)
>mapa generowana z bazy danych, a nie z plików danych lub programów graficznych
---

##### **mapa zasadnicza** (definicja)
>wielkoskalowe opracowanie kartograficzne zawierające aktualne informacje o przestrzennym rozmieszczeniu obiektów ogólnogeograficznych, elementów ewidencji gruntów, budynków, sieci uzbrojenia terenu
---

##### **skala** (definicja)
>stopień zmniejszania obrazu opisujący stosunek wielkości obrazu do oryginału
---

##### **geoida** (definicja)
>rzeczywista powierzchnia odniesienia Ziemi, która jest ciągłą, nieregularną bryłą zbliżoną kształtem do elipsoidy obrotowej
---

##### **wysokość ortometryczna punktu**/**wysokość nad poziomem morza** (definicja)
> odległość od geoidy do powierzchni Ziemi wzdłuż linii pionu
---

##### **wysokość elipsoidalna** (definicja)
> odległość od powierzchni Ziemi do elipsoidy
---

##### **undulacja geoidy**/**odstęp geoidy od elipsoidy** (definicja)
>różnica między wysokością ortometryczną a wysokością elipsoidalną
---

##### **system odniesienia**/***reference system*** (**IGiK 2004**) (definicja)
>zbiór zaleceń i ustaleń wraz z opisem modeli niezbędnych do zdefiniowania początku, skali i orientacji osi oraz ich zmienności w czasie
---

##### **układ odniesienia**/***reference frame*** (**IGiK 2004**) (definicja)
>praktyczna realizacja systemu odniesienia tworzona przez wyznaczone z pomiarów wartości parametrów opisujących początek układu, skalę i orientację osi oraz ich zmienności w czasie
---

##### **układ współrzędnych**/***coordinate system*** (**IGiK 2004**) (definicja)
>jednoznaczne określenie sposobu przyporządkowania zbioru wartości liczbowych (współrzędnych punktu) względem układu odniesienia
---

##### **osnowa geodezyjna** (definicja)
>usystematyzowany zbiór punktów geodezyjnych, których wzajemne położenie określono matematycznie
---

##### **punkt osnowy geodezyjnej** (definicja)
>punkt o znanym lub określonym położeniu
---

##### **znak geodezyjny** (definicja)
>obiekt trwale i stabilnie osadzony na powierzchni Ziemi, opatrzony trwałym znakiem identyfikowalnym jako punkt, którego położenie określono matematycznie (szerokość, długość, wysokość)
---

##### **osnowa podstawowa fundamentalna** (definicja)
>punkty wyznaczone w sieci o najwyższej dokładności, które przenoszące na kraj geodezyjny układ odniesienia i układ wysokości
---

##### **osnowa podstawowa bazowa** (definicja)
>punkty wyznaczone w sieci o najwyższej dokładności, które realizują przyjęte układy odniesienia i rozmieszczone są równomiernie na terenie kraju
---

##### **osnowa szczegółowa** (definicja)
>punkty wyznaczone w sieci, będące rozwinięciem podstawowej osnowy geodezyjnej i rozmieszczone w zależności od stopnia zurbanizowania terenu
---

##### **osnowa wysokościowa** (definicja)
>usystematyzowany zbiór punktów niwelacyjnych, których położenie względem poziomu odniesienia zostało wyznaczone przy zastosowaniu precyzyjnej techniki geodezyjnej
---

##### **odwzorowanie kartograficzne** (definicja I)
>sposób przeniesienia siatki geograficznej na płaszczyznę
---

##### **odwzorowanie kartograficzne** (definicja II)
>określona funkcja matematyczna wiążąca współrzędne punktów na elipsoidzie lub kuli ze współrzędnymi na płaszczyźnie
---

##### **informacja przestrzenna** (definicja)
>informacja o położeniu, geometrycznych właściwościach i przestrzennych relacjach obiektów, która może być odniesiona do powierzchni Ziemi
---

##### **izohipsa**/**poziomica**/**warstwica** (definicja)
>linia łącząca punkty o tej samej **wysokości**
---

##### **ekwidystanta** (definicja)
>linia łącząca punkty o jednakowej **odległości** od figury
---

##### **izobara** (definicja)
>linia łącząca punkty o tym samym **ciśnieniu**
---

##### **izobata** (definicja)
>linia łącząca punkty o tej samej **głębokości**
---

##### **izochroma** (definicja)
>linia łącząca punkty o jednakowym **czasie dostępu** od wybranego punktu w terenie
---

##### **izodensa** (definicja)
>linia łącząca punkty o jednakowym **gęstości zaludnienia**
---

##### **izogona** (definicja)
>linia łącząca punkty o jednakowej **deklinacji magnetycznej**
---

##### **izohela** (definicja)
>linia łącząca punkty o jednakowym **usłonecznieniu**
---

##### **izohieta** (definicja)
>linia łącząca punkty o tej samej ilości **opadów**
---

##### **izopora** (definicja)
>linia łącząca punkty o jednakowych zmianach wartości wielkości charakteryzujących **pole magnetyczne**
---

##### **izotacha** (definicja)
>linia łącząca punkty o tej samej **prędkości**
---

##### **izoterma** (definicja)
>linia łącząca punkty o tej samej **temperaturze**
---

##### **atrybutowanie** (definicja)
>nadawanie obiektom atrybutów lub cech
---

##### **identyfikator** (definicja)
>nadawany w trakcie wektoryzacji niepowtarzalny i jednoznacznie identyfikujący dany obiekt atrybut
---

##### **azymut** (definicja)
>kąt między kierunkiem północy magnetycznej a mierzonym kierunkiem
---

##### **powierzchnia pozioma** (definicja I)
>powierzchnia, do której linia pionu jest prostopadła w każdym punkcie
---

##### **powierzchnia pozioma** (definicja II)
>powierzchnia definiowana przez średni poziom morza
---

##### **powierzchnia horyzontalna** (definicja)
>powierzchnia, która jest styczna do powierzchni poziomej tylko w jednym punkcie
---

##### **linia celowa** (definicja)
>linia optyczna lunety instrumentu
---

##### **reper** (definicja)
>metalowy element z jednoznacznie określonym charakterystycznym punktem, którego wysokość jest wyznaczona
---

##### **pikieta** (definicja)
>punkt zmierzony pomiarem tachimetrycznym
---

##### **Numeryczny Model Wysokościowy** (**NMW**) (definicja)
>zbiór regularnie lub nieregularnie rozmieszczonych danych wysokościowych
---

##### ***Digital Terrain Model*** (**DTM**) (**C. Miller & R. Flamme 1958**) (definicja)
>*a Digital Terrain Model (DTM) is simply a statistical representation of the continuos surface of the ground by a large number of selected points with known X, Y, Z coordinates in an arbitrary coordinate field*
---

##### **Numeryczny Model Terenu **(**NMT**) (definicja I)
>zbiór danych wysokościowych uzupełnionych o informacje o rzeźbie terenu takie jak: linie szkieletowe, cieki, obszary bezodpływowe, skarpy, nasypy, drogi itp.
---

##### **Numeryczny Model Terenu** (**NMT**) (definicja II)
>uporządkowany zbiór danych reprezentujący przestrzenne rozmieszczenie jednej lub kilku informacji o terenie
---

##### **Numeryczny Model Terenu** (**NMT**) (definicja III)
>zbiór danych wysokościowych wraz z algorytmem pozwalającym na jej odtworzenie w danym obszarze
---

---
---
---
---
---
