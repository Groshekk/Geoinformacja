---
przedmiot: Systemy informacji geograficznej
date_zajec:
rodzaj_zajec:
prowadzacy: Anna Dmowska
date: 12.10.2023
type: notatki
tags: notatki, geoinformacja, studia, IIrok
---

# Zakres tematyczny zajęć
## Zakres tematyczny wykładów
1. Edycja, topologia i generalizacja danych wektorowych
2. Podstawowe analizy przestrzenne danych wektorowych
3. Analiza danych wektorowych z poziomu tabeli atrybutów
4. Podstawowe analizy przestrzenne danych rastrowych: funkcje lokalne, sąsiedztwa, strefowa, globalne
5. Analiza geomorfometryczna rzeźby terenu
6. Automatyzacja wykonywania analiz
7. Integracja i generalizacja danych przestrzennych
8. Interpolacja danych pomiarowych: punktowych i liniowych
9. Przykłady zastosowań GIS
---
## Zakres tematyczny laboratoriów
### Zakres tematyczny bloku **QGIS**
1. Analiza danych wektorowych w tabeli atrybutów
2. Podstawowe analizy przestrzenne danych wektorowych
3. Podstawowe analizy przestrzenne danych rastrowych
4. Analiza geomorfometryczna rzeźby terenu
5. Integracja danych: Analiza danych w oparciu o wiele kryteriów. Konwersja raster-wektor, wektor-raster
6. **Integracja QGIS i innego oprogramowania GIS**
---
### Zakres tematyczny bloku **ArcGIS**
1. **Edycja i topologia danych wektorowych**
2. **Interpolacja danych wektorowych**
3. Analiza danych wektorowych w tabeli atrybutów
4. Podstawowe analizy przestrzenne danych wektorowych
5. Podstawowe analizy przestrzenne danych rastrowych
6. Analiza geomorfometryczna rzeźby terenu
7. **Automatyzacja wykonywania analiz**
8. Integracja danych: analiza danych w oparciu o wiele kryteriów. Konwersja raster-wektor, wektor-raster
---
# Notatki
1. Wprowadzenie. Dane wektorowe
    - wprowadzenie
    - dane wektorowe
      - model wektorowy
      - topologia
      - generalizacja danych wektorowych
2. Konwersja danych wektorowych
3. Analiza danych wektorowych
    - buforowanie
    - nakładanie
    - selekcja danych
4. Przetwarzanie danych rastrowych
    - model rastrowy
    - wizualizacja danych rastrowych
    - przetwarzanie danych rastrowych
5. Podstawowe funkcje analizy danych rastrowych
    - funkcje lokalne
    - funkcje warunkowe
    - funkcje sąsiedztwa
    - funkcje strefowe
    - funkcje globalne
6. Automatyzacja analiz geoinformatycznych
7. Interpolacja przestrzenna
8. Zastosowania GIS
    - wprowadzenie
    - zastosowania GIS  
9. GIS w środowisku
    - wprowadzenie
    - GIS w leśnictwie
    - GIS w ochronie środowiska
    - GIS w rolnictwie
10. GIS w ochronie zdrowia
    - wprowadzenie
    - GIS w ochronie zdrowia
    - GIS w pogotowiu naukowym
    - GIS w szpitalu
    - GISCOVID-19
11. GIS w statystyce publicznej
    - statystyka publiczna
    - GIS w statystyce publicznej
---
---
---
---
---
# Definicje z notatek
##### **system informacji geograficznej** (**[ESRI](https://www.esri.pl/co-to-jest-gis/#0)**) (definicja)
>platforma do tworzenia, gromadzenia, zarządzania, analizowania i wizualizacji różnych typów danych
---

##### **system informacji geograficznej** (**J. Estman 2013**) (definicja)
>wspomagany komputerowo system gromadzenia, przechowywania, analizy i wyświetlania danych geograficznych
---

##### **system informacji geograficznej** (**Maguire 2011**) (definicja)
>zintegrowany sieciowo zestaw sprzętu komputerowego, oprogramowania, danych, metod bladawych i specjalistów, które to elementy działają w kontekście instytucjonalnym
---

##### **topologia** (definicja)
>dziedzina matematyki dotycząca relacji geometrycznych między elementami
---

##### **generalizacja** (*generalization*) (definicja)
>proces przekształcania obiektów wektorowych w taki sposób, aby zwierały zredukowaną liczbę szczegółów, co prowadzi do zmniejszenia liczby budujących je węzłów i odcinków
---

##### **bufor** (*buffer*) (definicja)
>wielobok otaczający obiekt lub grupę obiektów definiowany przez podaną odległość (wartość graniczna) jego krawędzi od krawędzi obiektu
---

##### **powierzchnia statystyczna** (*statistical surface*) (definicja)
>mapa rastrowa powstała w wyniku interpolacji przestrzennej
---

##### **telemedycyna** (definicja)
>monitorowanie informacji na temat stanu zdrowia pacjenta przebywającego poza szpitalem poprzez wyposażenie go w mobilne urządzenia, które same lub w połączeniu z telefonem komórkowym przekazują informacje do lekarza
---

##### **geomedycyna** (definicja)
>powiązanie lokalizacji z informacjami o występowaniu chorób powodowanych przez określone przyczyny i analizowanie stanu zdrowia pacjentów z wykorzystaniem historii miejsc zamieszkania
---

##### **statystyka publiczna** (***Ustawa z dnia 29 czerwca 1995 r. o statystyce publicznej***) (definicja)
>*system zbierania danych statystycznych, gromadzenia, przechowywania i opracowywania zebranych danych oraz ogłaszania, udostępniania i rozpowszechniania wyników badań statystycznych jako oficjalnych danych statystycznych*
---

##### **spis ludności** (***Encyklopedia PWN***) (definicja)
>*podstawowe badanie i źródło danych z zakresu statystyki ludności, które ma na celu zebranie informacji o jej stanie i strukturze według ustalonych cech demograficznych i społecznozawodowych, w oznaczonym momencie, na określonym terytorium*
---

##### **rejon statystyczny** (definicja)
>jednostka przestrzenna agregacji danych statystycznych złożona z kilku (do 9) obwodów spisowych
---

##### **obwód spisowy** (definicja)
>jednostka przestrzenna wyodrębniona dla spisów powszechnych i innych badań statystycznych według liczby mieszkań (do 200) i mieszkańców (do 500)
---

---
---
---
---
---





