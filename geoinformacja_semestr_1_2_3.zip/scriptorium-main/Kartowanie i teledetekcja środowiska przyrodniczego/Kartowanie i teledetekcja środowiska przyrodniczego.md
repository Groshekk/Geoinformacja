---
przedmiot: Kartowanie i teledetekcja środowiska przyrodniczego
date_zajec:
rodzaj_zajec: 
prowadzacy: Grzegorz Kowalewski, Jolanta Czerniawska
date: 17.10.2023
type: notatki
tags: notatki, geoinformacja, studia, IIrok
---

# Cel zajęć
- nabycie umiejętności **czytania i interpretacji wielkoskalowych tematycznych** map fizycznogeograficznych i map roślinności, map pokrycia terenu
- **opracowanie map fizycznogeograficznych, roślinności i pokrycia terenu** w skali topograficznej dla wybranego obszaru na podstawie integracji istniejących źródeł danych serii tematycznych
- **przygotowanie tematycznych map podkładowych** do *Ćwiczeń terenowych z kartowania i teledetekcji środowiska przyrodniczego*”
---
# Egzamin
## Zagadnienia na egzamin
#### część dr J. Czerniawiskiej
- rodzaje kartowania i danych pozyskiwanych w terenie
- etapy badań/kartowania środowiska
- kartowanie geologiczne - rodzaje prac, badań i zakres obserwacji terenowych (wg instrukcji **SMGP**)
- główne cechy kartowania geomorfologicznego
- poziomy/warstwy informacyjne Mapy Hydrograficznej Polski w skali *1:50 000*
#### część prof. G. Kowalewskiego
1. Omów sposoby przedstawiania rozmieszczenia gatunków organizmów żywych na świecie i w Polsce. Uwzględnij internetowe źródła danych.
2. Omów sposoby przedstawiania roślinności na mapach. Uwzględnij internetowe źródła danych.
3. Wyjaśnij genezę i rozmieszczenie typów zbiorowisk leśnych w Polsce w kontekście czynników środowiskowych.
4. Omów zagadnienie kartowania gleb w Polsce.
5. Omów *BDOT10k* w kontekście kartowania roślinności i flory.
---
# Bibliografia
- *Metody szczegółowych badań geografii fizycznej*; A. Richling
- *Geograficzne badania środowiska przyrodniczego*; A. Richling
- *Czwartorzęd. Osady, metody badań, stratygrafia*; L. Lindner
- *Kartografia tematyczna*; W. Żyszkowska, W. Spallek, D. Borowicz
- *Źródła i metody pozyskiwani danych przystępnych w badaniach środowiska przyrodniczego*; L. Kaczmarek, B. Medyńska-Gulij
- *Wytyczne kartowania terenowego w technologiach GIS i GPS przy wykorzystania VMap L2*; B. Medyńska-Gulij
---
# Zakres tematyczny zajęć
## Zakres tematyczny wykładów
1. Kartowanie środowiska
2. Mapy geologiczne
3. Mapy geomorfologiczne
4. Mapy hydrograficzne
5. Mapy geobotaniczne
6. Mapy florystyczne
7. Mapy pokrycia terenu
---
## Zakres tematyczny laboratoriów
1. Tło obszaru kartowania
2. Mapy geologiczne
3. Mapy geomorfologiczne
4. Mapy hydrograficzne
5. Mapy geobotaniczne
6. Mapy florystyczne
7. Mapy pokrycia terenu
---
# Etapy zajęć
## Etapy laboratoriów
1. nauka z istniejących map
2. przygotowanie własnych kompozycji map w *Layer Manager* (podkładowa, tematyczne) wraz z legendą i skalą
3. opisanie treści własnych map
4. tworzenie własnych styli do przygotowywanych map
5. nabycie wiedzy o dostępnych materiałach źródłowych 
---
## Etapy zajęć terenowych
1. rozpoznanie terenu
2. nanoszenie własnych elementów na mapę
3. generowanie map wynikowych
4. zaliczenie praktyk
---
# Notatki
## Notatki z wykładów
1. Obszar kartowania. Materiały źródłowe - treść na [stronie internetowej prof. G. Kowalewskiego](https://ichtys.web.amu.edu.pl/#)
2. Kartowanie ogólne i geologiczne
    - kartowanie ogólne
    - kartowanie geologiczne
3. Kartowanie geomorfologiczne
4. Kartowanie hydrograficzne
    - mapy tematyczne
    - Mapa Hydrograficzna Polski *1:50 000*
5. Kartowanie pokrycia terenu i biosfery - BDOT10k - treść na [stronie internetowej prof. G. Kowalewskiego](https://ichtys.web.amu.edu.pl/#)
6. Kartowanie gleb i roślinności - treść na [stronie internetowej prof. G. Kowalewskiego](https://ichtys.web.amu.edu.pl/#)
    - mapa glebowo-rolnicza
    - roślinność
7. Kartowanie flory i fauny - treść na [stronie internetowej prof. G. Kowalewskiego](https://ichtys.web.amu.edu.pl/#)
---
## Notatki z laboratoriów
1. Tło obszaru kartowania
2. Mapa geologiczna
3. Mapa geomorfologiczna
4. Mapa hydrogeologiczna i hydrograficzna
5. Mapa pokrycia terenu
6. Mapa glebowa
7. Aktualizacja mapy pokrycia terenu
---
# Definicje z notatek
##### **kartowanie** (definicja **I**)
>terenowa metoda pozyskiwania informacji o środowisku
---

##### **kartowanie** (definicja **II**)
>pozyskiwanie w terenie informacji/danych lokalizacyjnych (położenie, geometria) oraz atrybutowych (charakterystyki opisowa\e) wybranych komponentów środowiska przyrodniczego
---

##### **kartowanie środowiska** (definicja)
>określenie położenia, granic i cech jednostek oraz obiektów znajdujących się w obranie danego komponentu środowiska przyrodniczego
---

##### **kartowanie geologiczne** (definicja)
>metoda gromadzenia informacji o budowie geologicznej skorupy ziemskiej
---

##### **zdjęcie geologiczn**e (definicja) (**?**)
>całościowy zestaw graficznych i opisowych wyników badań geologicznych
---

##### **przekrój geologiczny** (definicja) (**?**)
>przedstawienie budowy fragmentu litosfery płaszczyzny cięcia
>poprowadzonej wzdłuż linii prostej poprzecznie do najbardziej reprezentatywnych struktur geologicznych
---

##### **profil geologiczny** (definicja) (**?**)
>synergiczny sposób przedstawienia następstw warstw geologicznych w odsłonięciach lub wierceniach
---

##### **litologia** (definicja)
>dział geologii zajmujący się charakterystyką fizyczną cech skał (kolor, skład mineralny, tekstura, struktura sedymentacyjna)
---

##### **stratygrafia** (definicja)
>dział geologii historycznej zajmujący się badaniem następstwa i wieku warstw skalnych
---

##### **tektonika** (definicja)
>dział geologii zajmujący się budową skorupy ziemskiej w kontekście ułożenia skał, ich fałdowania i innych deformacji oraz badający przyczyny, przebieg i skutki procesów prowadzących do deformacji skał
---

##### **roślinność** (definicja)
>ogół roślin tworzących naturalne skupienia, czyli zbiorowiska roślinne
---

##### **flora** (znaczenie I) (definicja)
>ogół gatunków roślin zamieszkujących dane terytorium w danym czasie
---

##### **flora** (znaczenie II) (definicja)
>rzymska bogini kwiatów i wiosny
---

##### **flora** (znaczenie III) (definicja)
>gatunek jakiejś margaryny
---

##### **kartografia geobotaniczna** (**Faliński 1991**) (definicja)
>*dziedzina kartografii tematycznej, która odpowiednio do treści, zakresu i potrzeb geobotaniki zajmuje się podstawami prezentacji i interpretacji na mapie zjawisk przestrzennych i przestrzenno-czasowych, zachodzących w szacie roślinnej i podległych jej układach i strukturach, w których komponent roślinny jest dominujący lub przynajmniej odgrywa zasadniczą rolę w ich organizacji, dynamice lub funkcji, niezależnie od wielkości zajmowanych przez nie powierzchni*
---

---
---
---
---
---
