---
autor: bm
przedmiot: Kartowanie i teledetekcja środowiska przyrodniczego
date_zajec:
rodzaj_zajec: 
prowadzacy: Grzegorz Kowalewski, Jolanta Czerniawska
date: 10.12.2023
type: notatki
tags: notatki, geoinformacja, studia, IIrok
---

# Zagadnienia egzaminacyjne
#### część dr J. Czerniawiskiej
- rodzaje kartowania i danych pozyskiwanych w terenie
- etapy badań/kartowania środowiska
- kartowanie geologiczne - rodzaje prac, badań i zakres obserwacji terenowych (wg instrukcji **SMGP**)
- główne cechy kartowania geomorfologicznego
- poziomy/warstwy informacyjne Mapy Hydrograficznej Polski w skali *1:50 000*
---
#### część prof. G. Kowalewskiego
1. Omów sposoby przedstawiania rozmieszczenia gatunków organizmów żywych na świecie i w Polsce. Uwzględnij internetowe źródła danych.
2. Omów sposoby przedstawiania roślinności na mapach. Uwzględnij internetowe źródła danych.
3. Wyjaśnij genezę i rozmieszczenie typów zbiorowisk leśnych w Polsce w kontekście czynników środowiskowych.
4. Omów zagadnienie kartowania gleb w Polsce.
5. Omów *BDOT10k* w kontekście kartowania roślinności i flory.
---
# Opracowanie zagadnień egzaminacyjnych
## Część dr J. Czerniawiskiej
### Rodzaje kartowania i danych pozyskiwanych w terenie
#### rodzaje kartowania
- kartowanie geomorfologiczne
- kartowanie geologiczne
- kartowanie gleb
- kartowanie wód
- kartowanie hydrologiczne
- kartowanie hydrogeologiczne
- kartowanie klimatu
- kartowanie florystyczne
- kartowanie faunistyczne
- kartowanie użytkowania terenu
- kartowanie sozologiczne
- kartowanie archeologiczne
- kartowanie specjalistyczne
---
### Etapy badań/kartowania środowiska
1. kwerenda - zbieranie danych, opracowań kartograficznych, literatury
2. badania terenowe
3. badania laboratoryjne
4. prace kameralne - opracowywanie wizualizacji graficznych
---
### Kartowanie  geologiczne – rodzaje prac, badań i zakres obserwacji terenowych (**SMGP**)
- zdjęcie geologiczne
- marszruta zdjęciowa
- punkt dokumentacyjny
- obserwacja geologiczna
- obserwacja geomorfologiczna
- badanie geofizyczne
- wiercenie badawcze dla **SMGP**
- lokalizacja wierceń i punktów dokumentacyjnych

**SMGP** - Szczegółowa Mapa Geologiczna Polski

---
### Główne cechy kartowania geomorfologicznego
-  celem określenie granic form ukształtowania terenu/form rzeźby, opisanie ich cech zewnętrznych
- podstawą mapa topograficzna z rysunkiem poziomicowym
- interpretacja przebiegu poziomic, odległości miedzy poziomicami umożliwia ustalenie granic, kształtu, innych cech zewnętrznych (_długość zbocza_) form geomorfologicznych
- obliczanie parametrów morfometrycznych (_spadek_, _deniwelacja_, _ekspozycja_)
- mapa geomorfologiczna produktem końcowym
---
### Poziomy/warstwy informacyjne Mapy Hydrograficznej Polski w skali *1:50 000*
- przedstawienie w _syntetycznym ujęciu warunki obiegu wody, w powiązaniu ze środowiskiem przyrodniczym, jego zainwestowaniem i przekształcaniem_
- wersja analogowa, wersja cyfrowa
- każdy obiekt jest zdefiniowany, posiada określone źródło geometrii i atrybutów, czas ich aktualizacji
- **VMAP 2** referencyjną bazą danych topograficznych - w przyszłości *Georeferencyjna Baza Danych Obiektów Topograficznych* (**GBDOT**), ortofotomapa cyfrowa, numeryczny model terenu
- układ odniesienia _1992_ (starsze w układach _1942_, _1965_)
---
#### poziomy informacyjne Mapy Hydrograficznej Polski w skali *1:50 000*
- topograficzne działy wodne
- wody powierzchniowe
- wypływy wód podziemnych
- wody podziemne pierwszego poziomu
- przepuszczalność gruntów
- zjawiska i obiekty gospodarki wodnej
- punkty hydrometryczne pomiarów
---
## Część prof. G. Kowalewskiego
### Omów sposoby przedstawiania rozmieszczenia gatunków organizmów żywych na świecie i w Polsce. Uwzględnij internetowe źródła danych.
#### zasięgi
Zasięgi gatunków to areał, obszar występowania na Ziemi określonej jednostki taksonomicznej, najczęściej gatunku. Zasięgi przedstawia się kartograficznie w postaci map. Wyróżniamy mapy zasięgowe o konstrukcji punktowej, liniowej (zarysowe) i kartogramy (mapy siatkowe, rastrowe). Zależnie od skali mapy uzyskujemy różną precyzję.  

---
#### mapa florystyczna
Mapa florystyczna przedstawia, poza nielicznymi wyjątkami tylko fragment generalnego zasięgu fitotaksonu w sposób:
- topogramiczny, czyli jako zbiór informacji punktowych o lokalizacji stanowisk w stosunku do przewodnich elementów terenu;
- kartogramiczny to jest w stosunku do określonych pól.
---
#### atlasy rozmieszczenia gatunków w Polsce
- Atlas rozmieszczenia roślin naczyniowych w Polsce
- [Atlas rozmieszczenia ssaków w Polsce](http://www.iop.krakow.pl/ssaki/)  
- [Atlas roślin w Polsce](http://www.atlas-roslin.pl/index.html)  
- Gatunki obce i inwazyjne w Polsce [Instytut Ochrony Przyrody PAN](https://www.iop.krakow.pl/ias)  
- Rozmieszczenie gatunków ptaków [2013-2018 (Art. 12 Dyrektywa ptasia)](https://inspire-geoportal.ec.europa.eu/download_details.html?view=downloadDetails&resourceId=%2FINSPIRE-d81e48c4-b4cf-11e3-a455-52540004b857_20230602-120602%2Fservices%2F1%2FPullResults%2F451-500%2Fdatasets%2F41&expandedSection=metadata)
---
#### atlasy rozmieszenia gatunków na świecie
- GBIF | Global Biodiversity Information Facility [Free and open access to biodiversity data](https://www.gbif.org/)  
- The Finnish Museum of Natural History [New grid system - Atlas Florae Europaeae](https://www.luomus.fi/en/new-grid-system-atlas-florae-europaeae)Finlandia [Atlas flory Finlandii 2006-2018](http://koivu.luomus.fi/kasviatlas/#haku)Finlandia [KASVIATLAS 2019](https://kasviatlas.fi/lajit/?key=Lobelia%20dortmanna&year=2021)Great Britain and Ireland [Botanical Society of Britain and Ireland](https://bsbi.org/maps?taxonid=2cd4p9h.8tb)Niemcy [Bundesamt fur Naturschutz. FloraWeb](https://www.floraweb.de/webkarten/karte.html?taxnr=3480)Holandia [FLORON Verspreidingsatlas Vaatplanten](https://www.verspreidingsatlas.nl/0754)
---
#### inne źródła danych
- Russia [Czerwona Księga](https://cicon.ru/lobelia-dortmanna.html)
- Belarus [Czerwona Księga](https://slounik.org/155085.html)
- Latvia [Gandrs Latvijas Daga](https://www.latvijasdaba.lv/augi/lobelia-dortmanna-l/)
- France [the National Inventory of the Natural Heritage](https://inpn.mnhn.fr/espece/cd_nom/106428?lg=en)
---
### Omów sposoby przedstawiania roślinności na mapach. Uwzględnij internetowe źródła danych.
Rozmieszczeniem roślinności i gatunków zajmuje się geografia roślin, zwana również fitogeografią. Kornaś i Medwecka-Kornaś (2002) wyróżniają florystyczną i socjologiczną geografię roślin, a także ekologiczną i historyczną geografię roślin. Faliński (1991) preferuje termin kartografia geobotaniczna, która definiuje jako *dziedzinę kartografii tematycznej, która odpowiednio do treści, zakresu i potrzeb geobotaniki zajmuje się podstawami prezentacji i interpretacji na mapie zjawisk przestrzennych i przestrzenno-czasowych, zachodzących w szacie roślinnej i podległych jej układach i strukturach, w których komponent roślinny jest dominujący lub przynajmniej odgrywa zasadniczą rolę w ich organizacji, dynamice lub funkcji, niezależnie od wielkości zajmowanych przez nie powierzchni*.

W tym kontekście autor ten wyróżnia cztery podstawowe terminy:
1. szata roślinna, reprezentowana na mapach geobotanicznych, np. mapy formacji roślinnych
2. roślinność, reprezentowana na mapach fitosocjologicznych
3. flora, reprezentowana na mapach florystycznych
4. fitocenoza, reprezentowana na napach fitoekologicznych wielkoskalowych
---
#### roślinność na świecie
- Biomy, czyli [formacje roślinne wraz ze światem zwierzęcym](https://pl.wikipedia.org/wiki/Biom)
- Ekoregiony [Ekoregiony świata](https://ecoregions.appspot.com/)
- Online Vegetation and Plant Distribution Maps: World [Strona University of California - roślinność i flora na świecie](http://guides.lib.berkeley.edu/VegMaps/world)
- Roślinność Europy [European Vegetation Archive (EVA)](http://euroveg.org/eva-database)
- Globalne bazy danych [Global Index of Vegetation-Plot Databases (GIVD)](https://www.givd.info/info_publications_related.xhtml)
---
#### roślinność w Polsce
- Roślinność potencjalna  - [Potencjalna roślinność naturalna Polski](https://www.igipz.pan.pl/Roslinnosc-potencjalna-zgik.html) Instytut Geografii i Przestrzennego Zagospodarowania  PAN
- Polska baza danych o roślinności [Polish Vegetation Database](https://www.ogrodbotaniczny.wroclaw.pl/polishvegetationdatabase.html)
---
#### lasy
- Corine Land Cover [HRL Forest 3](http://land.copernicus.eu/pan-european/high-resolution-layers/forests/view)
- [Bank Danych o Lasach](http://www.bdl.lasy.gov.pl/portal/)
- [Geomatyka w Lasach Państwowych + podręcznik](http://www.geomatyka.lasy.gov.pl/)
---
#### inne dane o roślinności
- Obiekty przyrodniczo cenne [Generalna Dyrekcja Ochrony Środowiska](http://geoserwis.gdos.gov.pl/mapy)
---
### Wyjaśnij genezę i rozmieszczenie typów zbiorowisk leśnych w Polsce w kontekście czynników środowiskowych.
#### Ekosystemy leśne
bory: sosnowe, świerkowe, mieszane; lasy liściaste: acydofilne dąbrowy i buczyny, żyzne buczyny, świetliste dąbrowy, grądy, łęgi jesionowo-wiązowe, łęgi jesionowo-olsowe, łęgi nadrzeczne, olsy

Lasy są pozostałością zbiorowisk, które niemal wyłącznie rosły w Polsce przed przybyciem pierwszych rolników. Wymienione powyżej [typy siedliskowe lasu](https://pl.wikipedia.org/wiki/Typ_siedliskowy_lasu) obrazują zróżnicowanie warunków siedliskowych w Polsce. Lasy rosną na siedliskach żyznych, dlatego większość z nich wykarczowano, a gleby wykorzystywane są rolniczo. Bory rosną na glebach mniej żyznych.

Polska leży w strefie klimatu umiarkowanego, co wpływa na rodzaje drzewostanów i roślinności. W północnej części kraju dominują lasy iglaste, głównie z sosną i świerkiem, ze względu na chłodniejszy klimat. Na południu, gdzie klimat jest cieplejszy, występują lasy liściaste z dębem, bukiem, grabem.

Rzeźba terenu, wilgotność gleb i dostępność wody także wpływają na rodzaje leśnych ekosystemów. W dolinach rzek można spotkać lasy łęgowe, a na stokach górskich występują lasy górskie.

---
### Omów zagadnienie kartowania gleb w Polsce.
Mapa **[glebowo-rolnicza](https://pl.wikipedia.org/wiki/Mapy_glebowo-rolnicze)** stanowi kompleksowe opracowanie gleboznawcze gruntów rolnych pod kątem ich przydatności rolniczej, klasyfikując je w kompleksy przydatności rolniczej gleb, gdzie wyróżniono 14 kompleksów dla gruntów ornych i 3 kompleksy dla użytków zielonych. Mapa przedstawia również opartą na kryteriach genetycznych (proces glebotwórczy) typologię gleb oraz rozróżnia oparte na kryteriach geologiczno-petrograficznych rodzaje (skała macierzysta) i gatunki gleb (uziarnienie). Obok kompleksów rolniczej przydatności wyróżnia się także VI klas **[bonitacyjnych](https://pl.wikipedia.org/wiki/Bonitacja_(gleboznawstwo))** gleb, oceniających ich jakość.

Legenda do mapy glebowo-rolniczej przypisuje wyróżnionym 18 typom oznaczenia literowe nie stosowane w obecnie obowiązującym, tj. szóstym wydaniu systematyki [Systematyce gleb Polski](https://pl.wikipedia.org/wiki/Systematyka_gleb_Polski), wyróżniającej 30 typów gleb oraz 183 podtypy. W nowej systematyce rodzaj gleby określa się na podstawie wieku (20 jednostek), genezy (16 jednostek) i rodzaju (75 jednostek) skały macierzystej, a gatunek gleby na podstawie uziarnienia.

Jeszcze inna klasyfikacja obowiązuje dla [gleb leśnych](https://pl.wikipedia.org/wiki/Klasyfikacja_gleb_leśnych_Polski). Zestawia ona typologię gleb z [typami siedliskowymi lasu](https://pl.wikipedia.org/wiki/Typ_siedliskowy_lasu) oraz zbiorowiskami roślinnymi. Powiązanie tych kategorii ma na celu przywrócenie w gospodarce leśnej większej zgodności siedliska z rosnącym na nim drzewostanem, bowiem relacje to zostały mocno zachwiane w toku setek lat gospodarki leśnej, głównie pod kątem jej pinetyzacji. Niestety, w klasyfikacji gleb leśnych obowiązują inne skróty, niż w systematyce gleb Polski. Klasyfikację gleb leśnych przedstawiono w [Atlasie gleb leśnych Polski](https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&ved=2ahUKEwjQx7Sr8dCCAxVkVPEDHZi7BL4QFnoECA4QAQ&url=https%3A%2F%2Fwww.lasy.gov.pl%2Fpl%2Fpublikacje%2Fcopy_of_gospodarka-lesna%2Fhodowla%2Fatlas-gleb-lesnych-polski%2F%40%40download%2Ffile%2FAtlas%2520gleb%2520lesnych%2520Polski.pdf&usg=AOvVaw22BYb6lZXABNo_KiMCxzAT&opi=89978449)Sławomira Brożka i Macieja Zwydaka natomiast zasady wyróżniania jednostek klasyfikacyjnych szczegółowo scharakteryzowano w [Instrukcji urządzania lasu](https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwjj45v79tCCAxXYVPEDHQN_AFAQFnoECA4QAQ&url=https%3A%2F%2Fwww.lasy.gov.pl%2Fpl%2Fpublikacje%2Fcopy_of_gospodarka-lesna%2Furzadzanie%2Fiul%2Finstrukcja-urzadzania-lasu-czesc-ii-dokument-przed-korekta%2F%40%40download%2Ffile%2FInstrukcja%2520urz%25C4%2585dzania%2520lasu_%2520cz%25202.pdf&usg=AOvVaw2Ylw4uM1g3NY59g4pSmLNF&opi=89978449) tom II.

W gleboznawstwie wyróżniamy jeszcze będące rezultatem procesu glebotwórczego [poziomy genetyczne gleb, diagnozowane nieco abrdziej subiektywnie](https://pl.wikipedia.org/wiki/Poziom_genetyczny_gleby) oraz, diagnozowane bardziej liczbowo, [poziomy diagnostyczne gleb](https://pl.wikipedia.org/wiki/Poziom_diagnostyczny_gleby), charakteryzowane wg mierzalnych cech morfologicznych i właściwości fizycznych i chemicznych.

Niepożądanym efektem istnienia różnych systemów klasyfikacyjnych gleb rolnych i leśnych jest niekompatybilność jednostek na mapach leśnych i użytków rolnych, co utrudnia skomponowanie mapy glebowej dla jednostki obejmującej grunty rolne i leśne.

---
### Omów BDOT10k w kontekście kartowania roślinności i flory.
#### § 27. PTLZ_A – tereny leśne lub zadrzewione
1. Klasa obiektów ‘OT_PTLZ_A’ reprezentuje tereny leśne lub zadrzewione.
2. Minimalna szerokość wydzielonego terenu leśnego lub zadrzewionego wynosi 10 m, a minimalna długość 40 m.
3. Grupę drzew, mały las lub zagajnik o powierzchni mniejszej niż 1000 m2 reprezentuje się przy pomocy obiektów klasy obiekt przyrodniczy.
4. W obrębie lasu wysokopiennego wydziela się zagajnik, jeżeli jego powierzchnia zajmuje ponad 2000 m2. Mniejsze zagajniki włącza się do lasu. Na obrzeżach lasu wydziela się zagajniki o powierzchni powyżej 1000 m2, a mniejsze włącza się do lasu.

---
#### § 28. PTRK_A – roślinność krzewiasta
1. Klasa obiektów ‘OT_PTRK_A’ reprezentuje tereny roślinności krzewiastej.
2. Jako obiekty klasy roślinność krzewiasta przedstawia się obszary o powierzchni przekraczającej 1000 m2. Mniejsze obszary przedstawia się, jako obiekty punktowe klasy obiekt przyrodniczy.
3. Pasy roślinności krzewiastej (gęstych krzewów) położone wzdłuż rzek reprezentuje się przez obiekty klasy roślinność krzewiasta, jeżeli ich szerokość jest równa lub większa niż 15 m, a ich powierzchnia większa niż 1000 m2. W innym przypadku pasy roślinności krzewiastej reprezentuje się jako obiekty liniowe klasy obiekt przyrodniczy.
4. Obszar roślinności krzewiastej (gęstych krzewów) wyróżnia się w obrębie lasu oraz na obrzeżach lasu, gdy jego powierzchnia przekracza 2000 m2. Mniejsze obszary włącza się do lasu.
---
#### § 29. PTUT_A – uprawy trwałe
1. Klasa obiektów ‘OT_PTUT_A’ reprezentuje tereny upraw trwałych [czyli sady, szkółki, ogrody, ogródki – GK].
2. Jako obiekty klasy uprawa trwała przedstawia się obszary o powierzchni powyżej 1000 m2 i szerokości większej niż 10 m.
---
#### 30. PTUT_A – roślinność trawiasta i uprawy rolne
1. Klasa obiektów ‘OT_PTTR_A’ reprezentuje tereny roślinności trawiastej i upraw rolnych.
2. Jako obiekty klasy roślinność trawiasta i uprawa rolna przedstawia się obszary o powierzchni powyżej 1000 m2 i szerokości większej niż 15 m. Wyjątkiem od tej zasady są przypadki szczególne, takie jak:
	- bardzo długie wydzielenia rozgraniczające dwa inne obiekty kategorii pokrycie terenu;
	- ronda;
	- tereny roślinności trawiastej między jezdniami, jeżeli ich szerokość jest większa niż 5 m.
3. Nie wprowadza się obszarów roślinności trawiastej mniejszych niż 500 m2
---
#### 74. ‘OT_OIPR_P’, ‘OT_OIPR_L’ reprezentują obiekty przyrodnicze.
1. Klasy obiektów ‘OT_OIPR_P’, ‘OT_OIPR_L’ reprezentują obiekty przyrodnicze.
2. Podstawą reprezentacji obiektów liniowych: linia oddziałowa, pas krzaków lub żywopłot, próg skalny, rząd drzew i wodospad jest linia umowna.
3. Podstawą reprezentacji obiektów punktowych: drzewo lub grupa drzew, głaz narzutowy lub grupa głazów, kępa krzewów, kępa kosodrzewiny, mały las, odosobniona skała, wejście do jaskini i źródło jest środek geometryczny.
4. W trakcie pozyskiwania danych dokonuje się generalizacji pierwotnej obiektów:
PUNKTOWYCH
- pozyskuje się odosobnione drzewa lub grupy drzew (OIPR01) zajmujących powierzchnię do 80 m2, rosnące na polach, łąkach, nad brzegami wód oraz w obrębie zagród. W przypadku licznego występowania blisko siebie rosnących drzew, generalizuje się je tak, aby odległość między drzewami nie była mniejsza niż 30 m;
- pozyskuje się małe lasy (OIPR06) lub skupiska drzew nie będące sadami, zajmujące obszar od 80 m2 do 1000 m2;
- pozyskuje się kępy krzewów (OIPR03), których powierzchnia jest mniejsza niż 1000 m2 oraz szerokość obszaru jest większa od 10 m. Punkt wstawienia umieszcza się w miejscu występowania zarośli lub w środku geometrycznym obszaru zakrzewionego. W przypadku licznego występowania blisko siebie kęp krzewów, generalizuje się je tak, aby odległość między nimi nie była mniejsza niż 60 m;
- pozyskuje się pojedyncze krzaki, kępy, a także odosobnione płaty [kępy] kosodrzewiny (OIPR04), których powierzchnia jest mniejsza od 1000 m2. W przypadku licznego występowania blisko siebie kęp kosodrzewiny, generalizuje się je tak, aby odległość między nimi nie była mniejsza niż 60 m; LINIOWYCH
- pozyskuje się rzędy drzew (OIPR10), gdy odstępy między drzewami są mniejsze lub równe 15 m, a długość rzędu wynosi co najmniej 40 m. Za pomocą tego obiektu przedstawia się również wąskie sady, niekwalifikujące się do przedstawienia w klasie ‘OT_PTUT_A’;
- pozyskuje się pasy krzewów lub żywopłoty (OIPR08), których szerokość nie przekracza 10 m oraz w przypadkach, gdy nie tworzą klasycznych pasów, jeśli są to krzaki rosnące wzdłuż dróg, rzek, kolei, rowów, skarp;
- pozyskuje się linie oddziałowe (OIPR05), gdy ich szerokość jest większa niż 2 m, a mniejsza niż 10 m; linię oddziałową o szerokości równej lub większej niż 10 m przedstawia się jako obiekt klasy pokrycie terenu zgodnie z rodzajem pokrycia występującego na tym terenie;
---
#### § 77. ‘OT_OIMK_A’ - mokradła
1. Klasa obiektów ‘OT_OIMK_A’ reprezentuje mokradła.
2. Klasa obiektów mokradło pozostaje w relacji nakładania się z niektórymi obiektami należącymi do kategorii obiektów pokrycie terenu.
---
#### § 78. ‘OT_OISZ_A’ - szuwary
1. Klasa obiektów ‘OT_OISZ_A’ reprezentuje szuwary
2. Klasa obiektów szuwary pozostaje w relacji nakładania się z obiektami klasy mokradło oraz z obiektami kategorii pokrycie terenu.
---
