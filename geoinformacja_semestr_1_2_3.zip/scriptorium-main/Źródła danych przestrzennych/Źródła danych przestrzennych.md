---
przedmiot: Źródła danych przestrzennych
date_zajec: 
rodzaj_zajec: wykład
prowadzacy: Lech Kaczmarek

date: 14.04.2023
type: notatki
tag: notatki, geoinformacja, studia, Irok, Moodle, egzamin
---
# Egzamin
## Zagadnienia egzaminacyjne
0. **Mapa** jako źródło danych przestrzennych
1. **Klasyfikacja** i **modelowanie** danych przestrzennych
2. **Zagadnienia prawnych mechanizmów** tworzenia i udostępniania danych przestrzennych w Polsce (INSPIRE, PIIP, przepisy wykonawcze)
3. **Metody udostępniania** danych przestrzennych. **Formaty** danych. **Usługi sieciowe**. **Geoportale**
4. **Systemy odniesień** przestrzennych. **Podziały sekcyjne** (arkuszowe) map i danych przestrzennych
5. Charakterystyka **analogowych źródeł** danych przestrzennych
6. **Metody cyfryzacji** źródeł analogowych
7. **Charakterystyka obrazowych źródeł** danych przestrzennych
8. **Charakterystyka wektorowych źródeł** danych przestrzennych
9. Przegląd współczesnych **systemów baz danych przestrzennych w Polsce**
10. **Charakterystyka atrybutowych źródeł** danych przestrzennych
11. **Jakość** i **potencjał informacyjny** danych przestrzennych
12. **Procedury wykorzystania** (w tym przetwarzania) danych źródłowych - **przykłady** projektów
---
## Pytania z egzaminu; 04.05.2023
1. Wymień nazwy trzech baz oraz ich formalnych skrótów nazw odpowiedzialnych za przechowywanie danych: działek, budynków i klasoużuytków, szczegółów sytuacyjnych terenu oraz sieci uzbrojenia terenu.
	- Ewidencja Gruntów i Budynków (EGIB), Geodezyjna Ewidencja Sieci Uzbrojenia Terenu (GESUT), Baza Danych Obiektów Topograficznych (BDOT500)
2. Co to są słowniki atrybutowe i do czego służą?
	- Słowniki atrybutowe to listy wszystkich możliwych wartości danych atrybutów oraz kodowanie tych wartości. Służą do budowania struktury bazy danych oraz odczytywania kodów.
3. Podaj nazwy tzw. rozszerzeń plików, które są wymagane, aby warstwa ESRI Shapefile była kompletna (podpowiedź: dla plików w formacie MS Word rozszerzenie to ".docx", a w starszych wersjach ".doc").
	- .shp; .shx; .dbf
4. Jakie informacje przechowują pliki .prj oraz identyfikatory EPSG?
	- .prj jako plik tekstowy zawiera informacje o odwzorowaniach i układzie współrzędnych. Identyfikatory EPSG przechowują wszystkie niezbędne informacje dla danych układów odniesienia - np. informacje o elipsoidzie odniesienia, sposobie rzutowania na płaszczyznę itp. - wszystkie niezbędne dla kartograficzności opisy matematyczne (systemy współrzędnych geograficznych itd.). Plik .prj nie współgra z kodami EPSG.
5. Co to jest redundancja baz danych i przepisy której ustawy jej przeciwdziałają?
	- Redundancja to nadmiarowość danych - np. dane zbędne tematycznie dla danej bazy danych. Kwestię tę reguluje *Ustawa o infrastrukturze informacji przestrzennej*
6. Napisz skale map o godłach: 1. N-33-142-A-a-3 (układ 1992); 2. 243.132 (układ 1965).
	- 1. 1:10 000; 2. 1:10 000
7. W której strefie odwzorowawczej i jakiego układu współrzędnych jest mapa geodezyjna o godle 6.172.17.242.3?
	- W strefie 6, układu odniesienia PL-2000.
8. Wymień cztery podstawowe kategorie typów danych atrybutowych.
	- Typ tekstowy (*string*), typ liczbowy całkowity (*integer*), typ liczbowy dziesiętny (*real*), typ liczbowy rzeczywisty, typ data, typ data i czas
9. Wymień elementy jakości danych wg EN ISO.
	- kompletność, spójność logiczna, dokładność przestrzenna, dokładność czasowa, dokładność tematyczna
10. Wymień etapy modelowania przestrzeni geograficznej wg Zeilera.
	- etap logiczny, etap konceptualny, etap fizyczny
11. Cyfrowa baza danych przestrzennych skalda się z:
	- A. nośnika danych i opisu
	- B. komputerów i ich użytkowników wymieniających się danymi
	- **C. zbiorów danych przestrzennych i systemu zarządzania bazą danych**
12. W jakiej nominalnej skali opracowania jest Baza Danych Obiektów Topograficznych?
	- **A. 1:10 000**
	- B. 1:5 000
	- C. 1:50 000
13. *Degradacja komponentów środowiska przyrodniczego* to grupa tematyczna danych:
	- A. mapy podziały hydrograficznego Polski
	- B. Bazy Danych Pokrycia Terenu
	- **C. Mapy Sozologicznej Polski**
14. Co wpływa na możliwość wizualizacji obiektów w klasach jednorodnych?
	- **A. obecność atrybutów opisowych**
	- B. obecność atrybutów logicznych
	- C. obecność atrybutów liczbowych
15. Co wpływa na możliwość wizualizacji obiektów w przedziałach klasowych?
	- **A. obecność atrybutów liczbowych**
	- B. obecność atrybutów opisowych
	- C. obecność atrybutów logicznych
16. Która z wymienionych baz danych zawiera informację na temat wodonośności?
	- A. Mapa Hydrograficzna Polski
	- **B. Mapa Hydrogeologiczna Polski**
	- C. Mapa Podziału Hydrograficznego Polski [błędnie wybrałem tę odpowiedź]
17. Który serwis udostępnia zasób topograficznych Polski?
	- A. pgi.gov.pl
	- B. gdos.gov.pl
	- **C. geoportal.gov.pl**
18. Warstwy tematyczne w danych cyfrowych odpowiadają:
	- A. warstwom farby drukarskiej nakładanej podczas produkcji map analogowych
	- **B. elementom legendy map analogowej**
	- C. całym bazą danych cyfrowych
19. Skrót CORINE jest związany z bazą:
	- A. hydrograficzną
	- B. ewidencji gruntów i budynków
	- **C. pokrycia terenu**
20. Które z cech lokalizują dane w przestrzeni geograficznej?
	- A. metadane
	- B. atrybuty opisowe
	- **C. współrzędne**
---
## Notatki
1. Mapa. Modelowanie
	- Mapa jako źródło danych przestrzennych
	- Dane przestrzenne. Modelowanie rzeczywistości. Modele danych przestrzennych
2. Modele danych. Udostępnianie danych
	- Dane przestrzenne. Modelowanie rzeczywistości. Modele danych przestrzennych
	- Źródła danych przestrzennych: postać, klasyfikacja i metody udostępniania
3. Układy współrzędnych. Polskie bazy danych przestrzennych
	- Układy współrzędnych i podziały przestrzenne danych
	- Dane wektorowe. Polskie bazy danych przestrzennych
4. BDOT10k. LIDAR. Pomiary terenowe. Atrybuty
	- Baza Danych Obiektów Topograficznych BDOT10k
	- LIDAR. Dane ze skaningu laserowego
	- Wyniki pomiarów i obserwacji terenowych. Atrybutowe źródła danych przestrzennych
5. Jakość danych. Potencjał danych
	- Jakość i potencjał informacyjny danych przestrzennych
	- Wykorzystanie danych cyfrowych w planowaniu przestrzennym
---
---
---
---
---
# Definicje z notatek

##### **mapa**
>graficzny **obraz** powierzchni Ziemi przedstawiony w zmniejszeniu w sposób: określony matematycznie, uogólniony, umowny
---

##### **encja**
>rzeczywisty lub abstrakcyjny **byt** wyróżniany w modelowanej rzeczywistości
---

##### **dane przestrzenne** (*Ustawa o infrastrukturze informacji przestrzennej* [INSPIRE])
>**dane** odnoszące się bezpośrednio lub pośrednio do określonego położenia lub obszaru geograficznego
---

##### **zbiór danych przestrzennych** (*Ustawa o infrastrukturze informacji przestrzennej* [INSPIRE])
>rozpoznawalny ze względu na wspólne cechy **zestaw danych przestrzennych**
---

##### **model**
>**system** założeń, pojęć i zależności między nimi pozwalający opisać (zamodelować) w przybliżony sposób jakiś aspekt rzeczywistości
---

##### **modelowanie**
>**proces** tworzenia modelu
---

##### **dane**
>**reprezentacja informacji** dla celów przetwarzania, interpretacji i/lub przekazywania (komunikowania), występująca w postaci znaków zrozumiałych dla człowieka lub nadających się do przetwarzania komputerowego
---

##### **atrybut**
> **cecha** opisująca obiekt, zjawisko
---

##### **ortorektyfikacja**
>**proces** przetworzenia obrazu fotogrametrycznego usuwający jego zniekształcenia spowodowane różnicami wysokości powierzchni terenowej, nachyleniem zdjęcia
---

##### **usługi sieciowe**
>**operacje** mogące być wykonywane przy użyciu oprogramowania komputerowego na danych zawartych w zbiorach danych przestrzennych lub na powiązanych z nimi metadanych
---

##### **metadane**
>**informacje** opisujące zbiory danych przestrzennych oraz usługi danych przestrzennych umożliwiające ich odnalezienie, inwentaryzację, używanie
---

##### **jakość danych** (ISO)
>kompletny **zespół cech i charakterystyki** zbiorów danych, które wpływają na możliwość zaspokojenia przez ten zbiór wymagań użytkownika
---

##### **potencjał informacyjny danych przestrzennych**
> miara zasobności modeli obiektów przestrzennych (encji) w informacje o cechach tych obiektów, istotnych z punktu widzenia indywidualnego użytkownika danych
---

##### **miara potencjału informacyjnego**
>suma miar ilościowych i jakości wg normy ISO - kompletności, spójności logicznej, dokładności czasowej i przestrzennej, a także dokładności tematycznej, która jest kluczowa przy określaniu potencjału
---

##### **dokładność tematyczna**
>cecha warstwy tematycznej, która w decydujący sposób wpływa na ilość i jakość przechowywanych danych oraz na możliwości analityczne i wizualizacyjne danych
---

---
