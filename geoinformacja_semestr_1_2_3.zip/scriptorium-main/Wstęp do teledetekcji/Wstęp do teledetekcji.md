---
przedmiot: Wstęp do teledetekcji
date_zajec:
rodzaj_zajec: wykład
prowadzacy: Jan Piekarczyk

date: 02.06.2023
type: notatki
tag: notatki, geoinformacja, studia, Irok, egzamin
---
# Egzamin
- 30 zadań typu *PRAWDA*/*FAŁSZ*
---
## Pytania z egzaminu; 30.06.2023
#### grupa I (moje odpowiedzi: *PRAWDA* / *FAŁSZ*)
- Pasywne czujniki teledetekcyjne rejestrują odbite i emitowane z powierzchni Ziemi promieniowanie elektromagnetyczne. [***PRAWDA***]
- Energia jest formą przenoszenia promieniowania. [***FAŁSZ***]
- Rośliny odbijają więcej promieniowania z zakresu bliskiej podczerwieni niż z zakresu widzialnego. [***PRAWDA***]
- W dni pochmurne dominuje w środowisku rozproszone promieniowanie słoneczne. [***PRAWDA***]
- Wraz ze wzrostem długości fali promieniowania elektromagnetycznego wzrasta jego energia. [***FAŁSZ***]
- W atmosferę ziemską wnika około 50% promieniowania słonecznego docierającego z przestrzeni kosmicznej. [***PRAWDA***]
- Pierwszą fotografię barwną wykonano na początku XX wieku w Szkocji. [***FAŁSZ***]
- Pierwsze zachowane zdjęcie z powietrza wykonano na początku XX w. [***FAŁSZ***]
- Fale radiowe są dłuższe od mikrofal. [***PRAWDA***]
- Emitowane z powierzchni Ziemi promieniowanie elektromagnetyczne rejestrują pasywne czujniki teledetekcyjne. [***PRAWDA***]
- Umowna wysokość nad Ziemią od której zaczyna się pułap satelitarny to 800 km. [***FAŁSZ***]
- Satelita geostacjonarny przemieszcza się z prędkością ok. 3,5 km/s. [***FAŁSZ***]
- Pierwsze zastosowanie zdjęć z powietrza w analizie wieloczasowej dotyczyło miasta Los Angeles. [***FAŁSZ***]
- Na wysokich orbitach okołoziemskich satelitów obserwacyjnych nie umieszcza się. [***PRAWDA***]
- Satelita okołobiegunowy przelatuje nad równikiem w innym miejscu przy kolejnych okrążeniach Ziemi. [***FAŁSZ***]
- Wadą optycznych czujników satelitarnych w stosunku do lotniczych jest ich większe uzależnienie od warunków pogodowych. [***PRAWDA***]
- Rejestracja zdjęć w zakresie bliskiej poczerwieni należy do metod teledetekcyjnych pasywnych. [***PRAWDA***]
- Aktywne metody teledetekcyjne polegają na tym, że czujnik rejestrujący obrazy przemieszcza się. [***FAŁSZ***]
- Piksel na zdjęciu wielospektralnym jest tym jaśniejszy im więcej energii dotrze do odpowiadającego mu piksela w matrycy czujnika. [***PRAWDA***]
- Obrazy zarejestrowane w pojedynczych kanałach czujnika wielospektralnego tworzą zdjęcie wielospektralne. [***PRAWDA***]
- Zdjęcie z kanału czerwonego czujnika satelitarnego składa się z pikseli w różnych odcieniach barwy czerwonej. [***FAŁSZ***]
- Kanał panchromatyczny służy do rejestracji zdjęć w zakresie bliskiej podczerwieni (NIR). [***FAŁSZ***]
- Rozdzielczość przestrzenna określa wielkość piksela na zdjęciu. [***FAŁSZ***]
- Czujnik hiperspektralny rejestruje odbite promieniowanie w kilku (do 20) zakresach widma elektromagnetycznego. [***FAŁSZ***]
- Na obrazie satelity Landsat OLI widoczne są pojedyncze drzewa. [***FAŁSZ***]
- Kierunek obserwacji „off-nadir” umożliwia zwiększenie rozdzielczości czasowej czujnika satelitarnego. [***PRAWDA***]
- Im większa rozdzielczość przestrzenna tym większą powierzchnię na Ziemi obejmuje jeden piksel obrazu. [***PRAWDA***]
- Zmiana kierunku obserwacji czujnika satelitarnego z nadirowego na skośny umożliwia częstszą rewizytę. [***PRAWDA***]
- Konstelacje najczęściej tworzą satelity różnych misji lub programów. [***FAŁSZ***]
- Rozwój teledetekcji zmierza w kierunku zmniejszania rozdzielczości przestrzennej i zwiększania rozdzielczości spektralnej. [***FAŁSZ***]
---
#### grupa II (moje odpowiedzi: *PRAWDA* / *FAŁSZ*)
4. Rośliny odbijają więcej promieniowania z zakresu bliskiej podczerwieni niż z zakresu widzialnego. [***PRAWDA***]
5. Pasywne czujniki teledetekcyjne rejestrują odbite i emitowane z powierzchni Ziemi promieniowanie elektromagnetyczne. [***PRAWDA***]
6. Energia jest formą przenoszenia promieniowania. [***FAŁSZ***]
7. W atmosferę ziemską wnika około 50% promieniowania słonecznego docierającego z przestrzeni kosmicznej. [***FAŁSZ***]
8. W dni pochmurne dominuje w środowisku rozproszone promieniowanie słoneczne. [***PRAWDA***]
9. Wraz ze wzrostem długości fali promieniowania elektromagnetycznego wzrasta jego energia. [***FAŁSZ***]
10. Fale radiowe są dłuższe od mikrofal. [***PRAWDA***]
1. Aktywne metody teledetekcyjne polegają na tym, że czujnik rejestrujący obrazy przemieszcza się. [***FAŁSZ***]
11. Pierwszą fotografię barwną wykonano na początku XX wieku w Szkocji. [***FAŁSZ***]
12. Pierwsze zachowane zdjęcie z powietrza wykonano na początku XX w. [***FAŁSZ***]
13. Pierwsze zastosowanie zdjęć z powietrza w analizie wieloczasowej dotyczyło miasta Los Angeles. [***FAŁSZ***]
2. Rejestracja zdjęć w zakresie bliskiej poczerwieni należy do metod teledetekcyjnych pasywnych. [***PRAWDA***]
14. Umowna wysokość nad Ziemią od której zaczyna się pułap satelitarny to 800 km. [***FAŁSZ***]
15. Satelita geostacjonarny przemieszcza się z prędkością ok. 3,5 km/s. [***FAŁSZ***]
3. Emitowane z powierzchni Ziemi promieniowanie elektromagnetyczne rejestrują pasywne czujniki teledetekcyjne. [***PRAWDA***]
16. Wadą optycznych czujników satelitarnych w stosunku do lotniczych jest ich większe uzależnienie od warunków pogodowych. [***PRAWDA***]
17. Na wysokich orbitach okołoziemskich satelitów obserwacyjnych nie umieszcza się. [***PRAWDA***]
18. Satelita okołobiegunowy przelatuje nad równikiem w innym miejscu przy kolejnych okrążeniach Ziemi. [***FAŁSZ***]
19. Zdjęcie z kanału czerwonego czujnika satelitarnego składa się z pikseli w różnych odcieniach barwy czerwonej. [***FAŁSZ***]
20. Piksel na zdjęciu wielospektralnym jest tym jaśniejszy im więcej energii dotrze do odpowiadającego mu piksela w matrycy czujnika. [***PRAWDA***]
21. Obrazy zarejestrowane w pojedynczych kanałach czujnika wielospektralnego tworzą zdjęcie wielospektralne. [***PRAWDA***]
22. Czujnik hiperspektralny rejestruje odbite promieniowanie w kilku (do 20) zakresach widma elektromagnetycznego. [***FAŁSZ***]
23. Kanał panchromatyczny służy do rejestracji zdjęć w zakresie bliskiej podczerwieni (NIR). [***FAŁSZ***]
24. Rozdzielczość przestrzenna określa wielkość piksela na zdjęciu. [***FAŁSZ***]
25. Im większa rozdzielczość przestrzenna tym większą powierzchnię na Ziemi obejmuje jeden piksel obrazu. [***PRAWDA***]
26. Na obrazie satelity Landsat OLI widoczne są pojedyncze drzewa. [***FAŁSZ***]
27. Kierunek obserwacji „off-nadir” umożliwia zwiększenie rozdzielczości czasowej czujnika satelitarnego. [***PRAWDA***]
28. Konstelacje najczęściej tworzą satelity różnych misji lub programów. [***FAŁSZ***]
29. Zmiana kierunku obserwacji czujnika satelitarnego z nadirowego na skośny umożliwia częstszą rewizytę. [***PRAWDA***]
30. Rozwój teledetekcji zmierza w kierunku zmniejszania rozdzielczości przestrzennej i zwiększania rozdzielczości spektralnej. [***FAŁSZ***]
---
## Notatki
1. **Wprowadzenie**
	- Teledetekcja
	- Energia i promieniowanie słoneczne
2. **Historia**
	- Fotografia ogólna
	- Fotografia lotnicza
	- Fotografia z kosmosu
3. **Pułapy rejestracji**
	- Kryteria podziału czujników spektralnych
	- Pułap lotniczy
	- Pułap satelitarny
4. **Czujniki spektralne. Landsat. Inne satelity**
	- Zobrazowania satelitarne
	- Rozdzielczości czujników spektralnych
	- Sposoby działania czujników spektralnych
	- Landsat
	- Czujniki innych satelitów
---
---
---
---
---
# Kamienie milowe w rozwoju teledetekcji
- **1858 r.** - pierwsze zdjęcia z balona
- **1861 r.** - pierwsze wykorzystanie balonów do zwiadu wojskowego
- **1909 r.** - pierwszy film lotniczy (Wilbur Wright, Włochy)
- **1946 r.** - pierwsze zdjęcie z kosmosu (rakieta V-2)
- **1957 r.** - pierwszy sztuczny satelita (Sputnik)
- **1960 r.** - pierwsze obserwacje orbitalne (satelita pogodowy TIROS-1)
- **1972 r.** - pierwszy satelita badawczy (Landsat)
- **1974 r.** - pierwszy satelita geostacjonarny (GOES)
- **1986 r.** - SPOT
- **1995 r.** - RADARSAT
- **1999 r.** - satelita Terra
- **2000 r.** - pierwszy satelita wysokorozdzielczy (IKONOS)
- **XXI w.** - bezzałogowe statki powietrzne
---
---
---
---
---
# Definicje z notatek

##### **teledetekcja** (krótko i ogólnie)
>pozyskiwanie danych o obiektach bez kontaktu z nimi z wykorzystaniem promieniowanie elektromagnetycznego
---

##### **teledetekcja** (kontekst geograficzny)
>technologia wykorzystywana do rejestracji promieniowania elektromagnetycznego w celu uzyskania i interpretacji danych geoprzestrzennych, na podstawie których można uzyskać informacje o cechach obiektów naziemnych i klasach pokrycia powierzchni Ziemi
---

##### **teledetekcja** (Fussell *et al.* 1986)
>bezkontaktowa rejestracja informacji o obiektach i powierzchniach na Ziemi za pomocą fali elektromagnetycznych w zakresie ultrafioletu, widma widzialnego, podczerwieni i mikrofali, przy wykorzystaniu kamer, skanerów, laserów liniowych i powierzchniowych umieszczonych na pokładach samolotów lub satelitów, a także analiza uzyskanych informacji poprzez interpretację wizualną lub obróbkę cyfrową
---

##### **energia**
>wielkość fizyczna charakteryzująca stan materii jako jej zdolności do wykonania pracy
---

##### **energia słoneczna**
>energia powstała w procesie termosyntezy, w której następuje zamiana masy na energię w wyniku połączenia się czterech protonów w jądro helu
---

##### **promieniowanie** (I)
>strumień cząstek (promieniowanie korpuskularne) lub fal wysyłanych przez ciało
---

##### **promieniowanie** (II)
>przepływ energii, który nie wymaga fizycznego kontaktu między ciałem wysyłającym i absorbującym energię
---

##### **długość fali** (***λ***)
>najmniejsza odległość pomiędzy dwoma powtarzającymi się fragmentami fali (np. wierzchołki) [μm / nm]
---

##### **częstotliwość fali** (***v***)
>liczba wierzchołków fali przechodzących przez dany punkt w czasie [Hz]
---

##### **widmo elektromagnetyczne**
>zestaw wszystkich długości fal wysyłanych przez Słońce i docierających do Ziemi
---

##### **promieniowanie rozproszone** / **promieniowanie nieba** (*diffuse solar radiation*)
>promieniowanie słoneczne dochodzące do powierzchni Ziemi z hemisfery nieba z wyłączeniem promieniowanie bezpośredniego
---

##### **okno atmosferyczne**
>zakres spektralny promieniowania elektromagnetycznego słabo pochłanianego prze atmosferę
---

##### **przenikalność atmosfery**
>...
---

##### ***dry-plate process*** (???)
> szklane płyty pokryte suchą emulsją bromo-żelatynową
---

##### **paleograf**
> urządzenie rejestrujące i wyświetlające obraz filmowy
---

##### **stereoskopia**
>metoda łączenia zdjęć wykonanych pod różnym kątem w celu uzyskania obrazu trójwymiarowego
---

##### **piksel**
>dwuwymiarowy, najmniejszy niepodzielny element obrazu cyfrowego
---

##### **kwantyfikacja**
>zmiana sygnału analogowego na cyfrowy, w efekcie której piksele mają zróżnicowane wartości jasności
---

##### **zdjęcie panchromatyczne**
>zdjęcie uzyskiwane w wyniku rejestracji odbitego promieniowania z szerokiego zakresu widma (kilkaset nanometrów) obejmującego pasmo widzialne, a często również bliską podczerwień
---

##### **kanał panchromatyczny** (?)
>kanał zbierający szerszy zakres widma elektromagnetycznego, co pozwala na zwiększenie rozdzielczości przestrzennej
---

##### **rozdzielczość przestrzenna**
>wielkość powierzchni Ziemi odpowiadająca jednemu pikselowi obrazu lub zdjęcia; im większa tym mniejsze obiekty można zaobserwować na obrazie satelitarnym lub zdjęciu lotniczym (jest ono bardziej szczegółowe)
---

##### **rozdzielczość czasowa** (**rewizyta**)
>minimalny czas w jakim czujnik teledetekcyjny może zaobserwować ponownie ten sam obraz na Ziemi; im wyższa rozdzielczość czasowa tym częściej uzyskuje się dane dla danego obszaru
---

##### **rozdzielczość spektralna**
> liczba i szerokość zakresów widma elektromagnetycznego (kanałów) w jakim czujnik rejestruje promieniowani; im większa rozdzielczość spektralna, tym bogatsze w informacje są dane i tym łatwiej określić rodzaj obiektów na obrazie satelitarnym lub lotniczym
---

##### **rozdzielczość radiometryczna**
>maksymalna liczba wartości jasności jaka może być przepisana pojedynczemu pikselowi (dynamika zakresu) wyrażana w bitach
---

---
---
---
---
---
